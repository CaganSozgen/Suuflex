/*
  Warnings:

  - Added the required column `ticker` to the `Tips` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Tips" ADD COLUMN     "ticker" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "total_suu_tips" DOUBLE PRECISION NOT NULL DEFAULT 0;
