/*
  Warnings:

  - You are about to drop the column `relevanceScore` on the `Comment` table. All the data in the column will be lost.
  - You are about to drop the column `email` on the `Creator` table. All the data in the column will be lost.
  - You are about to drop the column `tips` on the `Video` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[order]` on the table `Category` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "Creator_email_key";

-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "order" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "Comment" DROP COLUMN "relevanceScore";

-- AlterTable
ALTER TABLE "Creator" DROP COLUMN "email";

-- AlterTable
ALTER TABLE "Video" DROP COLUMN "tips",
ADD COLUMN     "total_tips" DOUBLE PRECISION NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "Tips" (
    "id" TEXT NOT NULL,
    "videoId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "tipperId" TEXT NOT NULL,

    CONSTRAINT "Tips_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Tips_videoId_idx" ON "Tips"("videoId");

-- CreateIndex
CREATE UNIQUE INDEX "Category_order_key" ON "Category"("order");

-- AddForeignKey
ALTER TABLE "Tips" ADD CONSTRAINT "Tips_videoId_fkey" FOREIGN KEY ("videoId") REFERENCES "Video"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Tips" ADD CONSTRAINT "Tips_tipperId_fkey" FOREIGN KEY ("tipperId") REFERENCES "Creator"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
