-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "card_thumbnail" TEXT;
