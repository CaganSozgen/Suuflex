import axios from "axios";

const BEARER_TOKEN ="AAAAAAAAAAAAAAAAAAAAAEO6vwEAAAAAjnmmncVgC9JLMGdVejXH9ZsWQoY%3DpY7RM0ZEU3AfLfkgP5Iw75QRKShh1zobsNOTsQ5GBI4le02RYn"

async function getTweetsByHashtag(hashtag: string, maxResults:number = 10) {
  try {
    const response = await axios.get(
      'https://api.twitter.com/2/tweets/search/recent',
      {
        params: {
          query: `#${hashtag} -is:retweet`, // Exclude retweets
          max_results: maxResults,
          'tweet.fields': 'created_at,public_metrics',
          'user.fields': 'name,username,profile_image_url',
          'expansions': 'author_id'
        },
        headers: {
          Authorization: `Bearer ${BEARER_TOKEN}`
        }
      }
    );

    const tweets = response.data.data;
    const users = response.data.includes.users;

    // Combine tweet data with user data
    const tweetsWithUserInfo = tweets.map(tweet => {
      const user = users.find(u => u.id === tweet.author_id);
      return {
        id: tweet.id,
        text: tweet.text,
        created_at: tweet.created_at,
        public_metrics: tweet.public_metrics,
        author: {
          id: user.id,
          name: user.name,
          username: user.username,
          profile_image_url: user.profile_image_url
        }
      };
    });

    return tweetsWithUserInfo;
  } catch (error) {
    return null;
  }
}


const hashtag = 'sui';
getTweetsByHashtag(hashtag)
  .then(tweets => {
    if (tweets) {
      tweets.forEach(tweet => {
        
        
        
        
        
        
        
      });
    }
  })
  .catch(error => console.error('Error:', error));