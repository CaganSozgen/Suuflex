import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function deleteAll() {
  await prisma.video.deleteMany();
  await prisma.videoVote.deleteMany();
  await prisma.creator.deleteMany();
  await prisma.comment.deleteMany();
  await prisma.commentVote.deleteMany();
  await prisma.category.deleteMany();
  await prisma.views.deleteMany();
}

deleteAll()
  .then(async () => {
    await prisma.$disconnect();
    
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
