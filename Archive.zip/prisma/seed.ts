import { faker } from '@faker-js/faker';
import { Category, Comment, Creator, PrismaClient, Tips, Video } from '@prisma/client';

const prisma = new PrismaClient();

async function createCategories(count: number): Promise<Category[]> {
  const categories: Category[] = [];
  for (let i = 0; i < count; i++) {
    const category = await prisma.category.create({
      data: {
        name: faker.commerce.department(),
        order: i,
      },
    });
    categories.push(category);
  }
  return categories;
}

async function createCreators(count: number): Promise<Creator[]> {
  const creators: Creator[] = [];
  for (let i = 0; i < count; i++) {
    const creator = await prisma.creator.create({
      data: {
        name: faker.name.fullName(),
        walletAddress: faker.finance.ethereumAddress(),
        profileImage: faker.image.avatar(),
        latestLogin: faker.date.recent(),
      },
    });
    creators.push(creator);
  }
  return creators;
}

async function createVideos(count: number, categories: Category[], creators: Creator[]): Promise<Video[]> {
  const videos: Video[] = [];
  for (let i = 0; i < count; i++) {
    const video = await prisma.video.create({
      data: {
        title: faker.lorem.words(5),
        description: faker.lorem.sentences(3),
        url: "https://www.youtube.com/watch?v=3MWwcP_A7zc",
        slug: faker.lorem.slug(),
        thumbnail: faker.image.url(),
        categoryId: categories[i % categories.length].id,
        creatorId: creators[i % creators.length].id,
      },
    });
    videos.push(video);
  }
  return videos;
}

async function createCommentsForVideos(videos: Video[], creators: Creator[]): Promise<Comment[]> {
  const comments: Comment[] = [];
  for (let i = 0; i < videos.length; i++) {
    const comment = await prisma.comment.create({
      data: {
        text: faker.lorem.sentence(),
        likes: faker.number.int({ min: 0, max: 100 }),
        dislikes: faker.number.int({ min: 0, max: 50 }),
        videoId: videos[i % videos.length].id,
        creatorId: creators[i % creators.length].id,
      },
    });
    comments.push(comment);
  }
  return comments;
}

async function createVotesForComments(comments: Comment[], creators: Creator[]): Promise<void> {
  for (let i = 0; i < comments.length; i++) {
    await prisma.commentVote.create({
      data: {
        likeOrDislike: faker.helpers.arrayElement(['LIKE', 'DISLIKE']),
        commentId: comments[i % comments.length].id,
        voterId: creators[i % creators.length].id,
      },
    });
  }
}

async function createVotesForVideos(videos: Video[], creators: Creator[]): Promise<void> {
  for (let i = 0; i < videos.length; i++) {
    await prisma.videoVote.create({
      data: {
        likeOrDislike: faker.helpers.arrayElement(['LIKE', 'DISLIKE']),
        videoId: videos[i % videos.length].id,
        voterId: creators[i % creators.length].id,
      },
    });
  }
}

async function createViewsForVideos(videos: Video[], creators: Creator[]): Promise<void> {
  for (let i = 0; i < videos.length; i++) {
    await prisma.views.create({
      data: {
        videoId: videos[i % videos.length].id,
        viewerId: creators[i % creators.length].id,
      },
    });
  }
}

// Function to create tips for videos
async function createTipsForVideos(videos: Video[], creators: Creator[]): Promise<Tips[]> {
  const tips: Tips[] = [];
  for (let i = 0; i < videos.length; i++) {
    const tip = await prisma.tips.create({
      data: {
        videoId: videos[i % videos.length].id,
        amount: faker.number.float({ min: 1, max: 1000, fractionDigits: 2 }),
        ticker: faker.finance.currencyCode(),
  tipperId: creators[faker.number.int({ min: 0, max: creators.length - 1 })].id
      },
    });
    tips.push(tip);
  }
  return tips;
}

async function main() {
  const categories = await createCategories(3);
  const creators = await createCreators(100);
  const videos = await createVideos(100, categories, creators);
  const comments = await createCommentsForVideos(videos, creators);
  
  await createVotesForComments(comments, creators);
  await createVotesForVideos(videos, creators);
  await createViewsForVideos(videos, creators);
  await createTipsForVideos(videos, creators);  // Add tips for videos
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
