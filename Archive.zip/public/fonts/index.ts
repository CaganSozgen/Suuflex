import { Alexandria, Shantell_Sans } from "next/font/google";

export const alexandria = Alexandria({
  subsets: ["latin"],
});

export const shantell = Shantell_Sans({
  subsets: ["latin"],
});
