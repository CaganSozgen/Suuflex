/** @type {import('next').NextConfig} */
const nextConfig = {
  env: {
    DATABASE_URL: process.env.DATABASE_URL,
    UPLOADTHING_TOKEN: process.env.UPLOADTHING_TOKEN,
    CONSUMER_API_KEY: process.env.CONSUMER_API_KEY,
    CONSUMER_SECRET_KEY: process.env.CONSUMER_SECRET_KEY,
    BEARER_TOKEN: process.env.BEARER_TOKEN,
    ACCESS_TOKEN: process.env.ACCESS_TOKEN,
    ACCESS_TOKEN_SECRET: process.env.ACCESS_TOKEN_SECRET,
    ADMIN_WALLET: process.env.ADMIN_WALLET,
    REDIS_URL: process.env.REDIS_URL,
  },
  images: {
    remotePatterns: [
      {
        hostname: "pbs.twimg.com",
      },
      {
        hostname: "cloudflare-ipfs.com",
      },
      {
        hostname: "avatars.githubusercontent.com",
      },
      {
        hostname: "placehold.co",
      },
      {
        hostname: "picsum.photos",
      },
      {
        hostname: "loremflickr.com",
      },
      {
        hostname: "utfs.io",
      },
    ],
  },
  // output: "export",
  // distDir: "build",
};

export default nextConfig;
