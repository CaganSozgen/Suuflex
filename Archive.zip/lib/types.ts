import { Prisma } from "@prisma/client";
import { Meta } from "./utils";

export type CommentWithRelations = Prisma.CommentGetPayload<{
  include: {
    votes: true;
    creator: true;
  };
}>;

export type VideoWithRelations = Prisma.VideoGetPayload<{
  include: {
    category: true;
    comments: {
      include: {
        votes: true;
        creator: true;
      };
    };
    videoVote: true;
    views: true;
    creator: true;
    tips: true;
  };
}>;


export interface ApiResponse<T> {
  message: string;
  data: T;
  meta?: Meta;
}

export interface Social {
  name: string;
  icon: string | React.ReactNode;
  href: string;
  isExternal?: boolean;
}