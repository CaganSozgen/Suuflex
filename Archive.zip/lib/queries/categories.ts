import { Category } from "@prisma/client";
import { ApiResponse } from "../types";
import { getErrorMessage } from "../utils";
import axios from "axios";

export const getCategories = async (): Promise<ApiResponse<Category[]>> => {
  try {
    const response = await axios.get("/api/categories");

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
