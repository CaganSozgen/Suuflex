import axios from "axios";
import { ApiResponse, VideoWithRelations } from "../types";
import { getErrorMessage } from "../utils";
import { Video } from "@prisma/client";

export const getCategorizedVideos = async () => {
  try {
    const response = await axios.get<ApiResponse<VideoWithRelations[]>>(
      "/api/videos"
    );

    const categorized_videos: Record<string, VideoWithRelations[]> = {};

    for (const video of response.data.data) {
      const categoryName = video.category?.name || "Uncategorized";

      if (!categorized_videos[categoryName]) {
        categorized_videos[categoryName] = [];
      }

      categorized_videos[categoryName].push(video);
    }

    for (const category in categorized_videos) {
      categorized_videos[category] = categorized_videos[category].slice(0, 8);
    }

    return categorized_videos;
  } catch (error) {
    throw getErrorMessage(error);
  }
};

export const getVideos = async () => {
  try {
    const response = await axios.get<ApiResponse<VideoWithRelations[]>>(
      `/api/videos`
    );

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};

export const getVideoCategory = async ({
  page = "1",
  limit = "10",
  category,
}: {
  page?: string;
  limit?: string;
  category: string;
}) => {
  try {
    const url = `/api/videos/category/${category}?page=${page}&limit=${limit}`;

    const response = await axios.get<ApiResponse<VideoWithRelations[]>>(url);

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};

export const getVideo = async (slug: string) => {
  try {
    const response = await axios.get<ApiResponse<VideoWithRelations>>(
      `/api/videos/${slug}`
    );

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};

export const getOtherVideos = async (slug: string) => {
  try {
    const response = await axios.get<ApiResponse<VideoWithRelations[]>>(
      `/api/videos/${slug}/other_videos`
    );

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};

export const getSuuNewsVideos = async () => {
  try {
    const response = await axios.get<ApiResponse<VideoWithRelations[]>>(
      "/api/videos/suunews"
    );

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
