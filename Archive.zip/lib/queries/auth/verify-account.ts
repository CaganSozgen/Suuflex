import { getErrorMessage } from "@/lib/utils";
import axios from "axios";

export const verifyAccount = async (
  walletAddress: string
): Promise<{
  isExisting: boolean;
}> => {
  try {
    const response = await axios.get(
      `/api/auth/verify-account?walletAddress=${walletAddress}`
    );

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
