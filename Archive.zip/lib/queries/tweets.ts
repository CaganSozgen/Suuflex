import axios from "axios";
import { ApiResponse } from "../types";
import { ApiV2Includes, TweetV2 } from "twitter-api-v2";

export interface TweetMeta {
  tweets: TweetV2[];
  meta: {
    newest_id: string;
    oldest_id: string;
    result_count: number;
    next_token?: string;
  };
  includes: ApiV2Includes | undefined;
}

export const fetchTweets = async ({ query }: { query: string }) => {
  try {

    const url = `/api/tweets?query=${encodeURIComponent(query)}`;
    const response = await axios.get<ApiResponse<TweetMeta>>(url);

    const data = response.data;

    return data;
  } catch (error) {
    console.error("Error fetching tweets:", error);
    throw error; // Rethrow the error to let the hook handle it
  }
};
