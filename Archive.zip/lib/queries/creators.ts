import axios from "axios";
import { getErrorMessage } from "../utils";
import { Creator } from "@prisma/client";

export const getCreators = async (): Promise<Creator[]> => {
  try {
    const response = await axios.get("/api/creators");
    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};


export const getCreator = async (id: string): Promise<Creator> => {
  try {
    const response = await axios.get(`/api/creators?id=${id}`);
    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
}