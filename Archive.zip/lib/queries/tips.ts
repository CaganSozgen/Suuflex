import axios from "axios";
import { getErrorMessage } from "../utils";
import { ApiResponse } from "../types";
import { Creator } from "@prisma/client";

interface Response {
  tipper: Creator;
  total_sui_donated: number;
  total_suu_donated: number;
}

interface TotalTipsResponse {
  name: string;
  value: number;
}

export const getLeaderboardTips = async () => {
  try {
    const response = await axios.get<ApiResponse<Response[]>>("/api/tips/leaderboard");
    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};


export const getTotalTips = async () => {

  try {
    const response = await axios.get<ApiResponse<TotalTipsResponse[]>>('/api/tips/total');

    return response.data
    
  } catch (error) {
    throw getErrorMessage(error);
  }
}