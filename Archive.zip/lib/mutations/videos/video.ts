import { ApiResponse } from "@/lib/types";
import { getErrorMessage } from "@/lib/utils";
import { Prisma, Video } from "@prisma/client";
import axios from "axios";

export const updateVideo = async ({ ...body }: Prisma.VideoUpdateInput) => {
  try {
    const response = await axios.patch(`/api/videos/${body.slug}`, body);

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};

export const createVideo = async ({ ...body }: Prisma.VideoCreateInput) => {
  try {
    const response = await axios.post<ApiResponse<Video>>(`/api/videos`, body);

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};


export const deleteVideo = async ({ slug }: {slug:string}) => {
  try {
    const response = await axios.delete(`/api/videos/${slug}`);

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
}