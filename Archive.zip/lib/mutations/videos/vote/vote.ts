import { ApiResponse } from "@/lib/types";
import { getErrorMessage } from "@/lib/utils";
import { VideoVote, VoteEnum } from "@prisma/client";
import axios from "axios";

export interface VoteBody {
  likeOrDislike: VoteEnum;
  voterId: string;
  slug: string;
}

export const videoVote = async ({ likeOrDislike, voterId, slug }: VoteBody) => {
  try {
    const response = await axios.post<ApiResponse<VideoVote>>(`/api/videos/${slug}/vote`, {
      likeOrDislike,
      voterId,
    });

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
