import { ApiResponse } from "@/lib/types";
import { getErrorMessage } from "@/lib/utils";
import { Creator, Prisma } from "@prisma/client";
import axios from "axios";

export const updateCreator = async ({
  body,
  id,
  walletAddress
}: {
  id: string;
  body: Prisma.CreatorUpdateInput;
  walletAddress: string;
}) => {
  try {
    const url = `/api/creators?id=${id}&walletAddress=${walletAddress}`;

    const response = await axios.patch<ApiResponse<Creator>>(url, body);
    
    return response.data;
  } catch (error) {
    throw getErrorMessage(error)
  }
}
;
