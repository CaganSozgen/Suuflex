import { getErrorMessage } from "@/lib/utils";
import axios from "axios";

interface CommentBody {
  videoId: string;
  text: string;
  creatorId: string;
}
export const submitComment = async ({
  text,
  creatorId,
  videoId,
}: CommentBody) => {
  try {
    const response = await axios.post(`/api/comments/${videoId}`, {
      text,
      creatorId,
    });

    return response.data
  } catch (error) {
    throw getErrorMessage(error);
  }
};
