import { getErrorMessage } from "@/lib/utils";
import { VoteEnum } from "@prisma/client";
import axios from "axios";

interface Params {
  videoId: string;
  commentId: string;
  voterId: string;
  vote: VoteEnum;
}

export const vote = async ({ commentId, videoId, voterId, vote }: Params) => {
  try {
    const response = await axios.post(
      `/api/comments/${videoId}/${commentId}/vote`,
      {
        likeOrDislike: vote,
        voterId,
        vote,
      }
    );

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
