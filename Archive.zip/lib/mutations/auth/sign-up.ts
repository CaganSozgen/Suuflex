import { ApiResponse } from "@/lib/types";
import { getErrorMessage } from "@/lib/utils";
import { Creator, Prisma } from "@prisma/client";
import axios from "axios";

export const signUp = async ({
  name,
  profileImage,
  walletAddress,
}: Prisma.CreatorCreateInput): Promise<ApiResponse<Creator>> => {
  try {
    const response = await axios.post("/api/auth/sign-up", {
      name,
      profileImage,
      walletAddress,
    });

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
