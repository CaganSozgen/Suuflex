import { ApiResponse } from "@/lib/types";
import { getErrorMessage } from "@/lib/utils";
import { Creator } from "@prisma/client";
import axios from "axios";

export const signIn = async (walletAddress: string):Promise<ApiResponse<Creator>> => {
  try {
    const response = await axios.post("/api/auth/sign-in", {
      walletAddress,
    });

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
