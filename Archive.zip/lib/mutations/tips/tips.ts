import { ApiResponse, VideoWithRelations } from "@/lib/types";
import { getErrorMessage } from "@/lib/utils";
import { Video } from "@prisma/client";
import axios from "axios";

interface Props {
  walletAddress: string;
  tipAmount: number;
  videoId: string;
  ticker: string;
}

export const addTip = async ({ tipAmount, walletAddress, videoId,ticker }: Props) => {
  try {
    const response = await axios.post<ApiResponse<Video>>(
      `/api/tips/${videoId}`,
      {
        walletAddress,
        tipAmount,
        ticker
      }
    );

    return response.data;
  } catch (error) {
    throw getErrorMessage(error);
  }
};
