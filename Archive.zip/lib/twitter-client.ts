import { TwitterApi } from "twitter-api-v2";

const twitterClient = new TwitterApi(process.env.BEARER_TOKEN ?? "");

const client = twitterClient.readOnly;

export default client;