import DexScreener from "@/icon/dex";
import Telegram from "@/icon/tg";
import X from "@/icon/x";
import { Social } from "./types";
import Hop from "@/icon/hop";

export const ALLOWED_WALLET_ADDRESS = [
  {
    owner: "Skyshare Labs 1",
    address:
      "0x2c4070e79d878d8d946f44d056a8c2a2b4f0177e72e1e9aca10e37c9509739d8",
  },
  {
    owner: "Skyshare Labs 2",
    address:
      "0x96d32f17bfb79b138952cf4bf7c5f73f241eaad01d2804273520e11e13436fbd",
  },
  {
    owner: "Skyshare Labs 3",
    address:
      "0x186435c70ba070285da7151b9474e96a38073a64cb1b687cb7e3bda0ea7965c2",
  },
  {
    owner: "Skyshare Labs 4",
    address:
      "0xe04fe1dec7b6b87f3251cb56a328ac9af8e50b8494e899aeb9d15a956ea0a89a",
  },
  {
    owner: "Skyshare Labs 5",
    address:
      "0xca7d2927fed3db5f32b9fe6682ce039e7dabc771e71278bbd2c24100babeb312",
  },
  {
    owner: "Yuupi",
    address:
      "0xd399f7da12809a32f38bfc3b2ec50bd637cb96480ef4fdb1c2dba533d4005cd1",
  },
];

export const ADMIN_WALLET =
  "0x5c1e355840d53ce5c5772ec32a23d7d54b888f63d6a104902e687da4d6231b52";
export const SUI_COIN_TYPE = "0x2::sui::SUI";
export const SUU_ADDRESS = "0xe49faf3eec344507eaadb6d21119d95823ae48b3540708489d492a5d8d9e79ed::suu::SUU"
export const SUU_OBJECT_ID =
  "0xdaae7f7964d2ecaf7455e96f6ee5875db8631246141350409398815b781d46b6";


  export const SITE_URL =
  process.env.NODE_ENV === 'production'
    ? 'https://suuflex.com'
    : 'http://localhost:3000'


export const SITE_NAME = 'Suuflex'
export const SITE_TITLE = 'Suuflex - Journey of SUU to the Suuuuuii ocean'
export const SITE_DESCRIPTION = 'One and only video streaming platform made on top of Sui Network.'

export  const socials: Social[] = [
    {
      name: "Twitter",
      icon: <X />,
      href: "https://x.com/Suuflex",
      isExternal: true,
    },
    {
      name: "Telegram",
      icon: <Telegram />,
      href: "https://t.me/+8zP2CY_8ILY3ZDc0",
      isExternal: true,
    },
    {
      name: "Hop Aggregator",
      icon: <Hop height={16} width={16} />,
      href: "https://hop.ag/swap/SUI-0xe49faf3eec344507eaadb6d21119d95823ae48b3540708489d492a5d8d9e79ed::suu::SUU",
      isExternal: true,
    },
    {
      name: "Dexscreener",
      icon: <DexScreener height={16} width={16} />,
      href: "https://dexscreener.com/sui/0xa8a65f8cb534c90348e74a4c1348b056325ba850d2b9280b8e0a1823e02986e1",
      isExternal: true,
    },
  ];