import { LucideProps } from "lucide-react";
import React from "react";

const X = ({ ...props }: LucideProps) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      {...props}
    >
      <path
        d="M1.16669 1.5H5.44447L14.8334 14.5H10.5556L1.16669 1.5Z"
        fill="#F2F6FF"
      />
      <path
        d="M14.8331 1.49988L2.96964 14.4999H1.16644L13.0299 1.49988H14.8331Z"
        fill="#F2F6FF"
      />
    </svg>
  );
};

export default X;
