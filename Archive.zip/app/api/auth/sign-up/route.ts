import prisma from '@/lib/db';
import { createApiResponse } from '@/lib/utils';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const { walletAddress, name, profileImage } = await req.json();

  if (!walletAddress || !name || !profileImage) {
    return NextResponse.json(
      { message: 'Wallet Address, name, and Profile Image are required' },
      { status: 400 }
    );
  }

  try {
    // Check if wallet address already exists
    const existingCreator = await prisma.creator.findUnique({
      where: { walletAddress },
    });

    if (existingCreator) {
      return NextResponse.json(
        { message: 'Account with this wallet address already exists' },
        { status: 409 }
      );
    }

    // Create a new creator account
    const creator = await prisma.creator.create({
      data: {
        walletAddress,
        name,
        profileImage,
      },
    });

    return NextResponse.json(createApiResponse("Account created successfully.",creator));
  } catch (error) {
    console.error('Error creating account:', error);
    return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
  }
}
