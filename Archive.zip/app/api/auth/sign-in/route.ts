import prisma from "@/lib/db";
import { createApiResponse, createErrorResponse } from "@/lib/utils";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { walletAddress } = await req.json();

  if (!walletAddress) {
    return NextResponse.json(
      { error: "Wallet address is required" },
      { status: 400 }
    );
  }

  try {
    // Check if the wallet address exists (Login)
    const creator = await prisma.creator.findUnique({
      where: { walletAddress },
    });

    if (!creator) {
      return NextResponse.json(
        { error: "Invalid wallet address" },
        { status: 401 }
      );
    }

    await prisma.creator.update({
      where: {
        id: creator.id,
      },
      data: {
        latestLogin: new Date(),
      },
    });

    // If the wallet address exists, log the user in
    return NextResponse.json(
      createApiResponse("Logged in successfully", creator)
    );
  } catch (error) {
    console.error("Error during login:", error);
    return NextResponse.json(
      createErrorResponse("An error occurred during login"),
      { status: 500 }
    );
  }
}
