import prisma from "@/lib/db";
import { createErrorResponse } from "@/lib/utils";
import { NextResponse } from "next/server";

export async function GET(request:Request) {
  const {searchParams} = new URL(request.url);
  const walletAddress = searchParams.get("walletAddress");

  if (!walletAddress) {
    return NextResponse.json({error: "Wallet address is required"}, {status: 400});
  }

  try {
    // Check if the wallet address exists (Login)
    const creator = await prisma.creator.findUnique({
      where: {walletAddress},
    });

    if (!creator) {
      return NextResponse.json({error: "Invalid wallet address"}, {status: 401});
    }

    // If the wallet address exists, log the user in
    return NextResponse.json({
      isExisting: true,
    });
    
  } catch (error) {
    console.error("Error during login:", error);
    return NextResponse.json(createErrorResponse("An error occurred during login"), {status: 500});
  }


}