import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { NextResponse } from "next/server";

export const GET = async (req: Request) => {
  try {
    const topTippers = await prisma.tips.groupBy({
      by: ["tipperId", "ticker"],
      _sum: {
        amount: true,
      },
    });

    const tipperIds = Array.from(new Set(topTippers.map((tipper) => tipper.tipperId)));

    const topTipperCreators = await prisma.creator.findMany({
      where: {
        id: {
          in: tipperIds,
        },
      },
    });

    const transformedData = tipperIds.map((tipperId) => {
      const tipper = topTipperCreators.find((creator) => creator.id === tipperId);
      const tipperData = topTippers.filter((tip) => tip.tipperId === tipperId);
      const totalSuiDonated = tipperData.find((tip) => tip.ticker === "SUI")?._sum.amount || 0;
      const totalSuuDonated = tipperData.find((tip) => tip.ticker === "SUU")?._sum.amount || 0;

      return {
        tipper,
        total_sui_donated: totalSuiDonated,
        total_suu_donated: totalSuuDonated,
      };
    });

    // Sort by total donated (SUI + SUU) in descending order
    transformedData.sort((a, b) => 
      (b.total_sui_donated + b.total_suu_donated) - (a.total_sui_donated + a.total_suu_donated)
    );

    // Take top 10
    const top10 = transformedData.slice(0, 10);

    return NextResponse.json(
      createApiResponse("Tip Leaderboard fetched successfully", top10),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error(error);
    return NextResponse.json(
      {
        message: "Internal Server Error",
      },
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
  }
};