import prisma from "@/lib/db"
import { createApiResponse } from "@/lib/utils"
import { NextResponse } from "next/server"

export const GET = async () => {
  try {
    const total_sui_donated = await prisma.tips.aggregate({
      _sum: {
       amount: true
      },
      where: {
        ticker: "SUI"
      }
    })

    const total_suu_donated = await prisma.tips.aggregate({
      _sum: {
       amount: true
      },
      where: {
        ticker: "SUU"
      }
    })

    const total_donators = await prisma.tips.aggregate({
      _count: {
        tipperId: true
      }
      
    })

    const transformedData = [
      {
        name: "Total $SUI Donated",
        value: total_sui_donated._sum.amount
      },
      {
        name: "Total $SUU Donated",
        value: total_suu_donated._sum.amount
      },
      {
        name: "Total Donators",
        value: total_donators._count.tipperId
      }
    ]



    return NextResponse.json(createApiResponse("Tips total fetched successfully", transformedData), {
      status: 200,
      headers: {
        "Content-Type": "application/json"
      }
    })

    
  } catch (error) {
    console.log({error})
    return NextResponse.json({message:"Internal Server Error"}, {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    })
  }
}