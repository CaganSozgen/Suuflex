import prisma from "@/lib/db"
import { createApiResponse } from "@/lib/utils"
import { NextResponse } from "next/server"

export const POST = async (req: Request, {
  params: {
    videoId
  }
}: {
  params: {
    videoId: string
  }
}) => {
  try {

    const { walletAddress, tipAmount,ticker} = await req.json()

    const video = await prisma.video.findUnique({
      where: {
        id: videoId
      }
    })

    if (!video) {
      return NextResponse.json({message: "Video not found"}, {
        status: 404,
        headers: {
          "Content-Type": "application/json"
        }
      })
    }

    const user = await prisma.creator.findUnique({
      where: {
        walletAddress: walletAddress,
      }
    })

    if(!user) {
      return NextResponse.json({message: "User not found"}, {
        status: 404,
        headers: {
          "Content-Type": "application/json"
        }
      })
    }

    const newTip = await prisma.tips.create({
      data: {
        amount: tipAmount,
        ticker: ticker,
        video: {
          connect: {
            id: video.id,
          }
        },
        tipper: {
          connect: {
            id: user?.id,
          }
        }
      },
    })

    const updatedVideo = await prisma.video.update({
      where: {
        id: video.id
      },
      data: {
        total_tips: {
          increment: ticker === "SUI" ? tipAmount : 0
        },
        total_suu_tips: {
          increment: ticker === "SUU" ? tipAmount : 0
        },
      }
    })

    return NextResponse.json(createApiResponse("Video tipped successfully.", updatedVideo), {
      status: 200,
      headers: {
        "Content-Type": "application/json"
      }
    })


    
  } catch (error) {
    return NextResponse.json({message: "Internal Server Error"}, {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    })
  }
}