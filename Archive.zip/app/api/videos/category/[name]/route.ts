import prisma from "@/lib/db";
import { createApiResponse, Meta } from "@/lib/utils";
import { NextResponse } from "next/server";

export const GET = async (
  req: Request,
  {
    params,
  }: {
    params: {
      name: string;
    };
  }
) => {
  try {
    const { searchParams } = new URL(req.url);
    const page = searchParams.get("page") || "1";
    const limit = searchParams.get("limit") || "10";
    const count = await prisma.video.count({
      where: {
        category: {
          name: params.name,
        },
      },
    });

    const category = await prisma.category.findUnique({
      where: {
        name: params.name,
      },
    });

    if (!category) {
      return NextResponse.json(
        {
          message: "Category not found",
        },
        {
          status: 404,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const videos = await prisma.video.findMany({
      where: {
        categoryId: category.id,
      },
      include: {
        category: true,
        comments: {
          include: {
            votes: true,
            creator:true,

          },
        },
        videoVote: true,
        views: true,
        creator: true,
        tips: true,
      },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
    });
    const totalPages = Math.ceil(count / Number(limit));

    const meta: Meta = {
      page: Number(page),
      totalPage: totalPages,
      remaining: count - Number(page) * Number(limit),
      hasNextPage: Number(page) < totalPages,
    };

    return NextResponse.json(
      createApiResponse("Videos retrieved successfully", videos, meta),
      {
        status: 200,
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: "Internal Server Error",
      },
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
};


// export async function generateStaticParams() {
//   const post = await prisma.category.findMany();

//   return post.map((category) => ({
//     params: { slug: category.name },
//   }));
// }