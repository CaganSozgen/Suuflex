import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { NextResponse } from "next/server";

export const GET = async (
  req: Request,
  { params }: { params: { slug: string } }
) => {
  try {
    const videos = await prisma.video.findMany({
      where: {
        slug: {
          not: params.slug,
        },
      },

      include: {
        videoVote: true,
        category: true,
        comments: {
          include: {
            votes: true,
            creator:true,
            
          },
        },
        creator: true,
        tips: true,
      },
      orderBy: {
        likes: "desc",
      }
    });

    return NextResponse.json(
      createApiResponse("Other videos fetched successfully", videos),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return NextResponse.json(
      { message: "Internal Server Error" },
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
};
