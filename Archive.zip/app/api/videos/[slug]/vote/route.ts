import prisma from "@/lib/db";
import {  VoteEnum } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export const POST = async (
  request: NextRequest,
  { params }: { params: { slug: string } }
) => {
  try {
    
    const body = await request.json();

    const video = await prisma.video.findUnique({
      where: { slug: params.slug },
    });

    if (!video) {
      return NextResponse.json(
        { message: "Video not found." },
        {
          status: 404,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const voterHasVoted = await prisma.videoVote.findFirst({
      where: {
        AND: [
          {
            videoId: video.id,
          },
          {
            voterId: body.voterId,
          },
        ],
      },
    });

    

    if (voterHasVoted) {
      return NextResponse.json(
        { message: "You already voted on this video." },
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        }
      );
    }
    /* export type VideoVoteCreateInput = {
    id?: string
    likeOrDislike: $Enums.VoteEnum
    createdAt?: Date | string
    updatedAt?: Date | string
    video: VideoCreateNestedOneWithoutVideoVoteInput
    voter: CreatorCreateNestedOneWithoutVideoVoteInput
  } */

    const vote = await prisma.videoVote.create({
      data: {
        likeOrDislike: body.likeOrDislike,
        video: {
          connect: {
            id: video.id,
          },
        },
        voter: {
          connect: {
            id: body.voterId,
          },
        },
      },
    });

    await prisma.video.update({
      where: { id: video.id },
      data: {
        likes:
          body.likeOrDislike === VoteEnum.LIKE
            ? {
                increment: 1,
              }
            : undefined,
        dislikes:
          body.likeOrDislike === VoteEnum.DISLIKE
            ? {
                increment: 1,
              }
            : undefined,
      },
    });

    return NextResponse.json(vote, {
      status: 201,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    
    return NextResponse.json(
      { message: "Failed to update video." },
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
};
