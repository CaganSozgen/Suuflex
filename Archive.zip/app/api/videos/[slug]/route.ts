import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  _: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const video = await prisma.video.findUnique({
      where: {
        slug: params.slug,
      },
      include: {
        category: true,
        comments: {
          include: {
            votes: true,
            creator: true,
          },
        },
        videoVote: true,
        views: true,
        creator: true,
        tips: true,
      },
    });

    return NextResponse.json(
      createApiResponse("Video fetched successfully", video),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: "Failed to get video." }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  const body = await request.json();

  if (!params.slug) {
    return new Response(JSON.stringify({ error: "slug is required." }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const video = await prisma.video.findUnique({
    where: { slug: params.slug },
  });

  if (!video) {
    return new Response(JSON.stringify({ error: "Video not found." }), {
      status: 404,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const updatedVideo = await prisma.video.update({
      where: { slug: params.slug },
      data: {
        ...body,
      },
    });
    return new Response(JSON.stringify(updatedVideo), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.log({ error });

    return new Response(
      JSON.stringify({ message: "Failed to update video." }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    if (!params.slug) {
      return new Response(JSON.stringify({ error: "slug is required." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const video = await prisma.video.findUnique({
      where: { slug: params.slug },
    });

    if (!video) {
      return NextResponse.json(
        { message: "Video not found." },
        {
          status: 404,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    await prisma.video.delete({
      where: { slug: params.slug },
    });

    return NextResponse.json(
      { message: "Video deleted successfully." },
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return NextResponse.json(
      { message: "Failed to delete video." },
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
}

// export async function generateStaticParams() {
//   const post = await prisma.video.findMany();

//   return post.map((video) => ({
//     params: { slug: video.slug },
//   }));
// }
