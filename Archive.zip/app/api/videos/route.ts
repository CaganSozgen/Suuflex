import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { Prisma } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const { ...body } = (await request.json()) as Prisma.VideoCreateInput;
    const video = await prisma.video.create({
      data: {
        ...body,
      },
    });

    return NextResponse.json(createApiResponse("Video uploaded successfully.", video), {
      status: 201,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    
    return NextResponse.json({message:"Failed to create video."}, {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}

export async function GET() {
  try {
    const videos = await prisma.video.findMany({
      orderBy: {
        category: {
          order: "asc",
        }
      },
      include: {
        category: true,
        comments: {
          include: {
            votes: true,
            creator:true,
          },
        },
        videoVote: true,
        views: true,
        creator: true,
        tips: true,
      },
    });

    return NextResponse.json(
      createApiResponse("Videos retrieved successfully", videos)
    , {
      status: 200,
    });

  } catch (error) {
    return NextResponse.json(
      {
        message: "Internal Server Error",
      },
      {
        status: 500,
      }
    );
  }
}
