import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { NextResponse } from "next/server";

export const GET = async (req: Request) => {
  try {
    const suunewsCategory = await prisma.category.findMany({
      where: {
        name: {
          equals: "Suunews",
        },
      },
    });

    if (!suunewsCategory.length) {
      return NextResponse.json(
        {
          message: "Category not found.",
        },
        {
          status: 404,
        }
      );
    }

    const suunews = await prisma.video.findMany({
      where: {
        category: {
          name: {
            equals: "SuuNews",
          },
        },
      },

      include: {
        category: true,
        comments: {
          include: {
            creator:true,
            votes: true,
          },
        },
        videoVote: true,
        views: true,
        creator: true,
      },
    });

    return NextResponse.json(
      createApiResponse("Videos fetched successfully.", suunews),
      {
        status: 200,
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: "Internal Server Error.",
      },
      {
        status: 500,
      }
    );
  }
};
