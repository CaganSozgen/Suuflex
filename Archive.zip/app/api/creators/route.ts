import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");

  if (id) {
    const creator = await prisma.creator.findUnique({
      where: { id },
    });
    return NextResponse.json(creator, {
      status: creator ? 200 : 404,
    });
  } else {
    const creators = await prisma.creator.findMany();
    return NextResponse.json(creators);
  }
}

export async function POST(request: Request) {
  const body = await request.json();
  const creator = await prisma.creator.create({
    data: body,
  });
  return NextResponse.json(creator);
}

export async function PATCH(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  const walletAddress = searchParams.get("walletAddress");
  const body = await request.json();

  if (!id) {
    return NextResponse.json({ error: "ID is required" }, { status: 400 });
  }

  const user = await prisma.creator.findUnique({
    where: { id },
  });

  if (!user) {
    return NextResponse.json({ error: "Creator not found" }, { status: 404 });
  }

  if(user.walletAddress !== walletAddress) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const updatedCreator = await prisma.creator.update({
    where: { id },
    data: body,
  });
  return NextResponse.json(
    createApiResponse("Creator updated successfully", updatedCreator),
    {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    }
  );
}

