import prisma from "@/lib/db";
import { NextResponse } from "next/server";

export const POST = async (req: Request, { params }: { params: { videoId: string, commentId: string } }) => {
  try {
    // Extract vote type (like or dislike) and voterId from the request body
    const { likeOrDislike, voterId } = await req.json();

    // Ensure the voter (creator) exists
    const voter = await prisma.creator.findUnique({
      where: {
        id: voterId,
      },
    });

    if (!voter) {
      return NextResponse.json({ message: "Voter not found." }, { status: 404 });
    }

    // Ensure the video exists
    const video = await prisma.video.findUnique({
      where: {
        id: params.videoId,
      },
    });

    if (!video) {
      return NextResponse.json({ message: "Video not found." }, { status: 404 });
    }

    // Ensure the comment exists
    const comment = await prisma.comment.findUnique({
      where: {
        id: params.commentId,
      },
    });

    if (!comment) {
      return NextResponse.json({ message: "Comment not found." }, { status: 404 });
    }


    // Check if the user has already voted on the comment
    const existingVote = await prisma.commentVote.findFirst({
      where: {
        commentId: params.commentId,
        voterId,
      },
    });

    if (existingVote) {
      // Update the existing vote
      await prisma.commentVote.update({
        where: {
          id: existingVote.id,
        },
        data: {
          likeOrDislike, // Update with the new vote type
        },
      });

      // Adjust likes/dislikes accordingly
      if (existingVote.likeOrDislike !== likeOrDislike) {
        await prisma.comment.update({
          where: {
            id: params.commentId,
          },
          data: {
            likes: likeOrDislike === "LIKE" ? { increment: 1 } : { decrement: 1 },
            dislikes: likeOrDislike === "DISLIKE" ? { increment: 1 } : { decrement: 1 },
          },
        });

      
      }

      return NextResponse.json({ message: "Vote updated successfully." }, { status: 200 });
    } else {
      // Create a new vote
      await prisma.commentVote.create({
        data: {
          likeOrDislike, // "LIKE" or "DISLIKE"
          commentId: params.commentId,
          voterId,
        },
      });

      // Increment likes or dislikes based on the vote
      await prisma.comment.update({
        where: {
          id: params.commentId,
        },
        data: {
          likes: likeOrDislike === "LIKE" ? { increment: 1 } : undefined,
          dislikes: likeOrDislike === "DISLIKE" ? { increment: 1 } : undefined,
        },
      });

  

      return NextResponse.json({ message: "Vote created successfully." }, { status: 201 });
    }
  } catch (error) {
    console.error(error);
    return NextResponse.json({ message: "Internal Server Error." }, { status: 500 });
  }
};
