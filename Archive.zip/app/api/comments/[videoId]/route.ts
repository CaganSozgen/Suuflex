// import prisma from "@/lib/db";
// import { NextResponse } from "next/server";

import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { NextResponse } from "next/server";

// export async function GET(request: Request) {
//   const { searchParams } = new URL(request.url);
//   const id = searchParams.get("id");
//   const videoId = searchParams.get("videoId");
//   const userId = searchParams.get("userId"); // Get user ID from query params

//   if (id && userId) {
//     const comment = await prisma.comment.findUnique({
//       where: { id },
//       include: {
//         votes: {
//           where: { voterId: userId }, // Filter votes by user ID
//         },
//       },
//     });
//     return NextResponse.json(comment);
//   } else if (videoId && userId) {
//     const comments = await prisma.comment.findMany({
//       where: { videoId },
//       include: {
//         votes: {
//           where: { voterId: userId }, // Filter votes by user ID
//         },
//       },
//     });
//     return NextResponse.json(comments);
//   } else {
//     return NextResponse.json(
//       { error: "ID or videoId is required" },
//       { status: 400 }
//     );
//   }
// }

// export async function POST(request: Request) {
//   const body = await request.json();
//   const { commentId, voterId, vote } = body;

//   const existingVote = await prisma.commentVote.findFirst({
//     where: {
//       commentId,
//       voterId,
//     },
//   });

//   if (existingVote) {
//     return NextResponse.json(
//       { error: "User has already voted on this comment" },
//       { status: 400 }
//     );
//   }

//   // Create a new vote
//   const commentVote = await prisma.commentVote.create({
//     data: {
//       commentId,
//       voterId,
//       vote,
//     },
//   });

//   // Optionally, update the comment's likes and dislikes
//   if (vote === "LIKE") {
//     await prisma.comment.update({
//       where: { id: commentId },
//       data: { likes: { increment: 1 } },
//     });
//   } else if (vote === "DISLIKE") {
//     await prisma.comment.update({
//       where: { id: commentId },
//       data: { dislikes: { increment: 1 } },
//     });
//   }

//   return NextResponse.json(commentVote);
// }


export const GET = async (req: Request,
  { params }: { params: { videoId: string } }
) => {
  try {
    const comments = await prisma.comment.findMany({
      where: { videoId: params.videoId },
    });

    return NextResponse.json(createApiResponse("Comments fetched successfully.", comments));
  } catch (error) {
    return NextResponse.json({ message: "Internal Server Error." }, { status: 500 });
  }
}

// POST route to submit a comment
export const POST = async (req: Request, { params }: { params: { videoId: string } }) => {
  try {
    // Extract the comment data from the request body
    const { text, creatorId } = await req.json();

    if(!text) {
      return NextResponse.json({ message: "Comment text is required." }, { status: 400 });
    }

    if(!creatorId) {
      return NextResponse.json({ message: "Creator ID is required." }, { status: 400 });
    }

    const video = await prisma.video.findUnique({
      where: {
        id: params.videoId,
      },
    });

    if (!video) {
      return NextResponse.json({ message: "Video not found." }, { status: 404 });
    }

    // Create the new comment
    const newComment = await prisma.comment.create({
      data: {
        text,
        videoId: video.id,
        creatorId, // This should be the ID of the user posting the comment
      },
    });

    // Return success response with the created comment
    return NextResponse.json({ comment: newComment }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ message: "Internal Server Error." }, { status: 500 });
  }
};
