import prisma from "@/lib/db";
import { createApiResponse } from "@/lib/utils";
import { NextResponse } from "next/server";

export const GET = async () => {
  try {
    const categories = await prisma.category.findMany({
      orderBy: {
        order: "asc",
      }
    });

    return NextResponse.json(
      createApiResponse("Categories fetched successfully.", categories),
      { status: 200 }
    );
  } catch (error) {
    
    return NextResponse.json(
      { message: "Internal Server Error" },
      { status: 500 }
    );
  }
};
