import { createApiResponse } from "@/lib/utils";
import { NextResponse } from "next/server";
import { TwitterApi } from "twitter-api-v2";
import { TwitterApiCachePluginRedis } from "@twitter-api-v2/plugin-cache-redis";
import { createClient } from "redis";

export const GET = async (req: Request) => {
  try {
    const redisInstance = createClient({
      url: process.env.REDIS_URL ?? '',
    });

    await redisInstance.connect();
    
    //@ts-expect-error redis Issue
    const redisPlugin = new TwitterApiCachePluginRedis(redisInstance); 

    const { searchParams } = new URL(req.url);
    const query = searchParams.get("query");

    if (!query) {
      return NextResponse.json(
        { message: "Query parameter is required." },
        { status: 400 }
      );
    }
    const twitter = new TwitterApi(process.env.BEARER_TOKEN ?? "", {
      plugins: [redisPlugin],
    });

    const client = twitter.readOnly;

    const response = await client.v2.search({
      query: `(${query}) -is:retweet has:hashtags`,
      max_results: 10,
      "tweet.fields": "created_at,public_metrics",
      "user.fields": "name,username,profile_image_url",
      "media.fields": "preview_image_url,url",
      expansions:
        "attachments.media_keys,author_id,referenced_tweets.id,referenced_tweets.id.author_id",
    });

    const tweets = response.data.data;
    const includes = response.data.includes;
    const meta = response.data.meta;

    const transformed_data = {
      tweets,
      meta,
      includes,
    };

    const data = createApiResponse(
      "Tweets fetched successfully.",
      transformed_data
    );

    return NextResponse.json(data, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { message: "Internal Server Error" },
      { status: 500 }
    );
  }
};
