import QueryProvider from "@/components/providers/query-provider";
import { ThemeProvider } from "@/components/providers/theme-provider";
import WalletProvider from "@/components/providers/wallet-provider";
import { Toaster } from "@/components/ui/sonner";
import { PropsWithChildren } from "react";
import "../globals.css";
import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";

const AdminRootLayout = ({ children }: PropsWithChildren) => {
  return (
    <html lang="en">
      <body className={cn(shantell.className)}>
        <WalletProvider>
          <QueryProvider>
            <ThemeProvider
              attribute="class"
              defaultTheme="dark"
              enableSystem
              disableTransitionOnChange
            >
              {children}
              <Toaster />
            </ThemeProvider>
          </QueryProvider>
        </WalletProvider>
      </body>
    </html>
  );
};

export default AdminRootLayout;
