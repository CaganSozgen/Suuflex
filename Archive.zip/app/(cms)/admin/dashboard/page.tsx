"use client";

import CreateVideo from "@/components/cms/videos/create";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { VideoDataTable } from "@/components/videos/data-table";
import useMounted from "@/hooks/useMounted";
import { ALLOWED_WALLET_ADDRESS } from "@/lib/constant";
import { useWallet } from "@suiet/wallet-kit";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

// Action Types
type MenuSelection = "videos";
type Action =
  | "create"
  | "getAll"
  | "getById"
  | "getByTitle"
  | "update"
  | "delete";

// Labels for actions
const actions: Record<MenuSelection, { label: string; value: Action }[]> = {
  videos: [
    { label: "Upload new Video", value: "create" },
    { label: "Get All Videos", value: "getAll" },
  ],
  /* community: [
    { label: "Create", value: "create" },
    { label: "Get All", value: "getAll" },
    { label: "Get By Id", value: "getById" },
    { label: "Update", value: "update" },
    { label: "Delete", value: "delete" },
  ],
  categories: [
    { label: "Create", value: "create" },
    { label: "Get All", value: "getAll" },
    { label: "Get By Id", value: "getById" },
    { label: "Update", value: "update" },
    { label: "Delete", value: "delete" },
  ], */
};

export default function AdminDashboard() {
  const [selectedMenu, setSelectedMenu] = useState<MenuSelection>("videos");
  const [selectedAction, setSelectedAction] = useState<Action | null>("getAll");
  const [inputValue, setInputValue] = useState("");
  const router = useRouter();
  const { connected, address } = useWallet();

  // Render dynamic content based on selected Menu (Videos, Community, Categories)
  const renderFormContent = () => {
    switch (selectedMenu) {
      case "videos":
        {
          // Handle the rest of the actions
          if (selectedAction === "create") {
            return <CreateVideo />;
          }
          // Render the videos
          if (selectedAction === "getAll") {
            return <VideoDataTable />;
          }

          /*     if (selectedAction === "getByTitle") {
          return <GetByIdVideo />;
        } */

          return null;
        }

        // Handle the "community" and "categories" menus in the same manner
        /*     case "community":
        return (
          <div>
            {selectedAction === "create" && (
              <>
                <Input
                  placeholder="Enter community name"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                />
              </>
            )}
            {selectedAction === "getById" && (
              <>
                <Input
                  placeholder="Enter community ID"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                />
              </>
            )}
          </div>
        );
      case "categories": */
        return (
          <div>
            {selectedAction === "create" && (
              <>
                <Input
                  placeholder="Enter category name"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                />
              </>
            )}
            {selectedAction === "getById" && (
              <>
                <Input
                  placeholder="Enter category ID"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                />
              </>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  useEffect(() => {
    if (connected && address) {
      const walletIsAllowed = ALLOWED_WALLET_ADDRESS.find(
        (allowedAddress) => allowedAddress.address === address
      );

      if (!walletIsAllowed) {
        router.push("/dashboard");
      }

    }
  }, [address, connected, router]);

  return (
    <div className="flex flex-col w-full min-h-screen">
      <header className="sticky top-0 z-50 flex items-center h-16 gap-4 px-4 border-b bg-background md:px-6">
        <nav className="flex-col hidden gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
          {Object.keys(actions).map((menu) => (
            <Button
              variant="ghost"
              key={menu}
              className={`bg-none text-muted-foreground transition-colors hover:text-foreground ${
                selectedMenu === menu ? "text-foreground" : ""
              }`}
              onClick={() => setSelectedMenu(menu as MenuSelection)}
            >
              <p className="capitalize">{menu}</p>
            </Button>
          ))}
        </nav>
      </header>
      <main className="flex min-h-[calc(100vh_-_theme(spacing.16))] flex-1 flex-col gap-4 bg-muted/40 p-4 md:gap-8 md:p-10">
        <div className="grid w-full gap-2 mx-auto">
          <h1 className="text-3xl font-semibold capitalize">{selectedMenu}</h1>
        </div>
        <div className="">
          {actions[selectedMenu].map((action) => (
            <Button
              key={action.value}
              variant="ghost"
              className="font-semibold text-primary"
              onClick={() => setSelectedAction(action.value)}
            >
              {action.label}
            </Button>
          ))}
        </div>
        {renderFormContent()}

        {/*   <div className="mx-auto grid w-full max-w-6xl items-start gap-6 md:grid-cols-[180px_1fr] lg:grid-cols-[250px_1fr]">
          <nav className="grid gap-4 text-sm text-muted-foreground">
            {actions[selectedMenu].map((action) => (
              <Button
                key={action.value}
                variant="ghost"
                className="font-semibold text-primary"
                onClick={() => setSelectedAction(action.value)}
              >
                {action.label}
              </Button>
            ))}
          </nav>
          <div className="grid gap-6">
            <Card x-chunk="dashboard-04-chunk-1">
              <CardHeader>
                <CardTitle>
                  {selectedAction ? selectedAction : "Select an Action"}
                </CardTitle>
                <CardDescription>
                  {selectedAction
                    ? `Perform the ${selectedAction} action for ${selectedMenu}`
                    : `Choose an action for ${selectedMenu} from the menu.`}
                </CardDescription>
              </CardHeader>
              {renderFormContent()}
            </Card>
          </div>
        </div> */}
      </main>
    </div>
  );
}
