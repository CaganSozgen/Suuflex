"use client";

import { Button } from "@/components/ui/button";
import { ALLOWED_WALLET_ADDRESS } from "@/lib/constant";
import { useWallet } from "@suiet/wallet-kit";
import { useRouter } from "next/navigation";
import React from "react";

const AdminPage = () => {
  const { address } = useWallet();
  const router = useRouter();

  const isAllowed = ALLOWED_WALLET_ADDRESS.find(
    (wallet) => wallet.address === address
  );


  //api.twitter.com/2/tweets/search/recent?query="#Technology" -is:retweet has:images&expansions=author_id&tweet.fields=created_at,public_metrics

  https: return (
    <main className="h-screen grid place-content-center">
      {isAllowed ? (
        <Button
          onClick={() => {
            router.push("/admin/dashboard");
          }}
          className="p-4 border border-blue-100 text-base font-semibold  cursor-pointer"
        >
          Authenticate.
        </Button>
      ) : (
        <Button
          onClick={() => {
            router.push("/");
          }}
          className="p-4 border border-blue-100 text-base font-semibold  cursor-pointer"
        >
          You are not allowed to access this page.
        </Button>
      )}
    </main>
  );
};

export default AdminPage;
