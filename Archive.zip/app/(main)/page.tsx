import Onboarding from "@/views/onboarding/onboarding";

export default function Home() {
  return (
    <main>
      <Onboarding />
    </main>
  );
}
