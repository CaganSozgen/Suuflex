import { getVideos } from "@/lib/queries/videos";
import DescriptionSection from "@/views/dashboard/description-section";

interface Props {
  params: {
    slug: string;
  };
}

const DescriptionPage = async ({ params }: Props) => {
  return <DescriptionSection slug={params.slug} />;
};

export default DescriptionPage;


// export async function generateStaticParams(){
//   const videos = await getVideos();
//   const paths = videos.data.map((video) => ({
//     params: { slug: video.slug },
//   }));

//   return paths;
// }