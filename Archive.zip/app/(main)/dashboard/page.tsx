"use client";
import CategoryCarousel from "@/components/category-carousel";
import CategorySectionSkeleton from "@/components/skeletons/category-section";
import TweetSidebar from "@/components/tweet-sidebar";
import { getCategorizedVideos, getVideos } from "@/lib/queries/videos";
import HeroSection from "@/views/dashboard/hero-section";
import { useQuery } from "@tanstack/react-query";
import React from 'react';

const Dashboard = () => {
  const {
    data: videos,
    isLoading: videosIsLoading,
    isError: videosIsError,
    error: videosError,
    isSuccess: videosIsSuccess,
  } = useQuery({
    queryFn: () => getCategorizedVideos(),
    queryKey: ["videos"],
  });

  const { data:uncategorized_videos } = useQuery({
    queryFn: getVideos,
    queryKey: ["uncategorized-videos"],
  });


  return (
    <main className="flex min-h-[1024px] flex-col items-center gap-16 flex-1 w-full">
      <HeroSection videos={uncategorized_videos} />

      <div className="container flex flex-col flex-wrap items-start self-stretch justify-center gap-4 md:flex-row">
        <div className="flex-1 w-full space-y-16">
          {videosIsLoading && (
            <div className="space-y-16">
              <CategorySectionSkeleton />
              <CategorySectionSkeleton />
              <CategorySectionSkeleton />
            </div>
          )}

          {videos && videosIsSuccess && (
            <>
              {Object.entries(videos).map(([category, categorized_videos]) => {
                return (
                  <>
                    <CategoryCarousel
                      category={category}
                      videos={categorized_videos}
                      key={category}
                      viewAll={true}
                    />
                  </>
                );
              })}
            </>
          )}
        </div>
        <div className="mt-16 md:mt-0 md:max-w-[320px]">
          <TweetSidebar />
        </div>
      </div>
    </main>
  );
};

export default Dashboard;
