'use client';

import { CompleteCreatorProfileForm } from '@/components/forms/complete-account';

const CompleteDetailsPage = () => {
  return (
    <main className="min-h-screen grid place-content-center">
      <CompleteCreatorProfileForm />
    </main>
  );
}

export default CompleteDetailsPage