import HowToBuySection from "@/views/dashboard/aboutsuu/how-to-buy-section";
import RoadmapSection from "@/views/dashboard/aboutsuu/roadmap-section";
import TokenomicsSection from "@/views/dashboard/aboutsuu/tokenomics-section";
import HeroSection from "@/views/dashboard/hero-section";
import React from "react";

const AboutSuuuPage = () => {
  return (
    <main className="flex min-h-[1024px] flex-col items-center gap-16 flex-1">
      <HeroSection videos={undefined} />

      <RoadmapSection />
      <TokenomicsSection />
      <HowToBuySection />
    </main>
  );
};

export default AboutSuuuPage;
