import Footer from "@/components/footer";
import Navbar from "@/components/navbar";
import ModalProvider from "@/components/providers/modal-provider";
import ProgressProvider from "@/components/providers/progress-provider";
import QueryProvider from "@/components/providers/query-provider";
import { ThemeProvider } from "@/components/providers/theme-provider";
import WalletProvider from "@/components/providers/wallet-provider";
import { Toaster } from "@/components/ui/sonner";
import type { Metadata } from "next";
import "../globals.css";
import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";
import SmoothScroll from "@/components/providers/smooth-scrool-provider";
import { TailwindIndicator } from "@/components/tailwind-indicator";
import { SITE_DESCRIPTION, SITE_NAME, SITE_TITLE, SITE_URL } from "@/lib/constant";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: SITE_TITLE,
    template: `%s | ${SITE_TITLE}`,
  },
  description: SITE_DESCRIPTION,
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  manifest: "/favicon/site.webmanifest",
  twitter: {
    card: "summary_large_image",
    title: SITE_NAME,
    description: SITE_DESCRIPTION,
    images: [
      {
        url: `${SITE_URL}/assets/og.png`,
        width: 3000,
        height: 1000,
        alt: SITE_DESCRIPTION,
      },
    ],
  },
  openGraph: {
    url: SITE_URL,
    type: "website",
    title: SITE_TITLE,
    siteName: SITE_TITLE,
    description: SITE_DESCRIPTION,
    locale: "en-US",
    images: [
      {
        url: `${SITE_URL}/assets/og.png`,
        width: 3000,
        height: 1000,
        alt: SITE_DESCRIPTION,
        type: "image/png",
      },
    ],
  },
  icons: {
    icon: "/favicon/favicon.svg",
    shortcut: "/favicon/favicon.svg",
    apple: [
      {
        url: "/favicon/apple-touch-icon.png",
        sizes: "180x180",
        type: "image/png",
      },
    ],
    other: [
      {
        rel: "icon",
        type: "image/png",
        sizes: "16x16",
        url: "/favicon/favicon-16x16.png",
      },
      {
        rel: "icon",
        type: "image/png",
        sizes: "32x32",
        url: "/favicon/favicon-32x32.png",
      },
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={cn(shantell.className)}>
        <WalletProvider>
          <QueryProvider>
            <ThemeProvider
              attribute="class"
              defaultTheme="dark"
              enableSystem
              disableTransitionOnChange
            >
              <SmoothScroll disabledPage={['/']}>
                <main className="flex flex-col min-h-screen">
                  <Navbar />
                  <div className="flex-grow">{children}</div>
                  <Footer />
                </main>
                <Toaster />
                <ModalProvider />
                <ProgressProvider />
                <TailwindIndicator />
              </SmoothScroll>
            </ThemeProvider>
          </QueryProvider>
        </WalletProvider>
      </body>
    </html>
  );
}
