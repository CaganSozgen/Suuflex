"use client";
import CategorySection from "@/components/category-carousel";
import { Button } from "@/components/ui/button";
import prisma from "@/lib/db";
import { getCategories } from "@/lib/queries/categories";
import { getVideoCategory, getVideos } from "@/lib/queries/videos";
import { ApiResponse, VideoWithRelations } from "@/lib/types";
import HeroSection from "@/views/dashboard/hero-section";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

interface Props {
  params: {
    category: string;
  };
}

const AllVideosInCategoryPage = ({ params }: Props) => {
  const [page, setPage] = useState<number>(1);

  const { data: videos } = useQuery<ApiResponse<VideoWithRelations[]>>({
    queryKey: ["videos", params.category, page],
    queryFn: async () =>
      getVideoCategory({
        page: page.toString(),
        limit: "10",
        category: params.category,
      }),
  });

  const { data: uncategorized_videos } = useQuery({
    queryFn: getVideos,
    queryKey: ["uncategorized-videos"],
  });

  const hasNextPage = videos?.meta?.hasNextPage;

  return (
    <main className="space-y-16">
      <HeroSection videos={uncategorized_videos} />

      <CategorySection
        inSection={true}
        viewAll={false}
        category={params.category}
        videos={videos?.data}
      />

      <div className="mt-4 flex flex-1 justify-center items-center gap-2">
        <Button
          variant={"outline"}
          disabled={page === 1}
          onClick={() => setPage(page - 1)}
          className=""
        >
          Previous
        </Button>
        <Button
          variant={"outline"}
          disabled={!hasNextPage}
          onClick={() => setPage(page + 1)}
          className=""
        >
          Next
        </Button>
      </div>
    </main>
  );
};

export default AllVideosInCategoryPage;

