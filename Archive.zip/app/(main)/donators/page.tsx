"use client";

import TweetSidebar from "@/components/tweet-sidebar";
import { Skeleton } from "@/components/ui/skeleton";
import { getLeaderboardTips, getTotalTips } from "@/lib/queries/tips";
import { getOtherVideos } from "@/lib/queries/videos";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import OtherVid from "@/views/dashboard/other-video";
import { formatAddress } from "@mysten/sui/utils";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import numeral from "numeral";
import React from "react";

const LeaderboardsPage = () => {
  const { data: tips, isLoading: isLoadingTips } = useQuery({
    queryFn: getLeaderboardTips,
    queryKey: ["leaderboardTips"],
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });

  const { data: total_tips, isLoading: isLoadingTotalTips } = useQuery({
    queryFn: getTotalTips,
    queryKey: ["totalTips"],
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });

    const { data: other_videos } = useQuery({
    queryFn: () => getOtherVideos(encodeURIComponent("")),
    queryKey: ["other-videos"],
  });

  return (
    <main className="flex min-h-[1024px] pt-[128px] flex-col items-center gap-16 flex-1">
      <section
        id="leaderboard"
        className="flex p-8 flex-col items-center self-stretch"
      >
        <div className="flex container items-start gap-8 self-stretch">
          <div className="flex flex-col items-start gap-8 flex-1">
            <div className="flex items-start gap-4 self-stretch">
              {isLoadingTotalTips && (
                <React.Fragment>
                  <Skeleton className="max-w-[288px] flex-1 h-[96px]" />
                  <Skeleton className="max-w-[288px] flex-1 h-[96px]" />
                  <Skeleton className="max-w-[288px] flex-1 h-[96px]" />
                </React.Fragment>
              )}

              {total_tips?.data.map((tip, index) => {
                return (
                  <div
                    key={index}
                    className="flex max-w-[288px] p-4 flex-col justify-center items-start gap-2 flex-1"
                  >
                    <p className="ty-h5">{numeral(tip.value).format("0a")}</p>
                    <p
                      className={cn(
                        alexandria.className,
                        "ty-descriptions text-white/50"
                      )}
                    >
                      {tip.name}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="flex flex-col items-start gap-3 self-stretch">
              <h3 className={cn(shantell.className, "ty-h3 text-white")}>
                Top Donators
              </h3>
            </div>

            <div className="flex flex-col justify-center items-start gap-3 self-stretch rounded-lg">
              <div className="flex p-4 flex-col justify-center items-start gap-2 self-stretch rounded-lg ring ring-white/[.08px]">
                <div className="flex items-center gap-3 self-stretch">
                  <div className="w-6"></div>
                  <div className="flex items-center gap-4 flex-1">
                    <p
                      className={cn(
                        alexandria.className,
                        "ty-descriptions flex-1 text-white/[.72]"
                      )}
                    >
                      Address
                    </p>

                    <div className="flex items-start gap-2 flex-1">
                      <div className="flex flex-col items-start gap-2 flex-1">
                        <p
                          className={cn(
                            alexandria.className,
                            "text-white/[.72]"
                          )}
                        >
                          Total $SUI Donated
                        </p>
                      </div>
                      <div className="flex flex-col items-start gap-2 flex-1">
                        <p
                          className={cn(
                            alexandria.className,
                            "text-white/[.72]"
                          )}
                        >
                          Total $SUU Donated
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="w-6"></div>
                </div>
              </div>

              <div className="flex flex-col items-start gap-2 self-stretch">
                {tips?.data.length === 0 && (
                  <div className="flex min-h-[200px] flex-col items-center justify-center w-full">
                    <p className="text-center max-w-[50%]">
                      &quot;Uh-oh! Looks like the tip jar is as empty as a
                      Monday morning coffee cup. 🧐 No tippers in sight.
                      Let&rsquo;s hope generosity is just fashionably late!
                      💸👀&quot;
                    </p>
                  </div>
                )}

                {isLoadingTips && (
                  <>
                    <Skeleton className="w-full h-[36px]" />
                    <Skeleton className="w-full h-[36px]" />
                    <Skeleton className="w-full h-[36px]" />
                    <Skeleton className="w-full h-[36px]" />
                    <Skeleton className="w-full h-[36px]" />
                    <Skeleton className="w-full h-[36px]" />
                  </>
                )}

                {tips?.data.map((tip, index) => {
                  const colorMap: Record<number, string> = {
                    0: "bg-[#FFD700] text-black",
                    1: "bg-[#C0C0C0] text-black",
                    2: "bg-[#D5964F] text-black",
                  };

                  return (
                    <div
                      key={index}
                      className="flex p-4 flex-col justify-center items-start gap-2 self-stretch rounded-lg ring ring-white/[.08]"
                    >
                      <div className="flex items-center gap-3 self-stretch">
                        <div
                          className={cn(
                            "flex w-[24px] p-[3px_8px_2px_8px] justify-center items-center rounded-[4px]",
                            colorMap[index] ?? "bg-[#1E1E1E]"
                          )}
                        >
                          <p
                            className={cn(shantell.className, "font-semibold")}
                          >
                            {index + 1}
                          </p>
                        </div>

                        <div className="flex items-center gap-4 flex-1">
                          <p
                            className={cn(
                              alexandria.className,
                              "ty-descriptions text-white/[.72] flex-1"
                            )}
                          >
                            {formatAddress(tip.tipper.walletAddress)}
                          </p>

                          <div className="flex items-start gap-2 flex-1">
                            <div className="flex flex-col items-start gap-2 flex-1">
                              {numeral(tip.total_sui_donated).format("0,0")}
                            </div>
                            <div className="flex flex-col items-start gap-2 flex-1">
                              {numeral(tip.total_suu_donated).format("0,0")}
                            </div>
                          </div>
                        </div>

                        <Link
                          href={`https://suiscan.xyz/mainnet/account/${tip.tipper.walletAddress}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <ArrowUpRight size={16} />
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
          <div className="mt-16 md:mt-0 md:max-w-[320px]">
            {/* {other_videos && other_videos.data && <OtherVid other_videos={other_videos.data} />} */}

            <TweetSidebar />
          </div>
        </div>
      </section>
    </main>
  );
};

export default LeaderboardsPage;
