"use client";

import Profile from "@/components/profile";
import { Button } from "@/components/ui/button";
import { getVideos } from "@/lib/queries/videos";
import { useAuthStore } from "@/store/authStore";
import HeroSection from "@/views/dashboard/hero-section";
import { useQuery } from "@tanstack/react-query";


const ProfilePage = () => {
  const { user } = useAuthStore();

    const { data: uncategorized_videos } = useQuery({
      queryFn: getVideos,
      queryKey: ["uncategorized-videos"],
    });

  if (!user) return null;

  return (
    <main className="space-y-16">
      <HeroSection videos={uncategorized_videos}/>

      <div className="flex justify-center items-stretch container flex-1 w-full gap-4">
        <div className="max-w-[320px] w-full rounded-lg border border-white/[.20] p-3">
          <Profile />
        </div>
      </div>
    </main>
  );
};

export default ProfilePage;
