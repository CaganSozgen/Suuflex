import { create } from "zustand";

interface useEditProfileModalStore {
  isOpen: boolean;
  onOpen: () => void;
  onClose: () => void;
}

export const useEditProfileModal = create<useEditProfileModalStore>((set) => ({
  isOpen: false,
  onOpen: () =>
    set({
      isOpen: true,
    }),
  onClose: () =>
    set({
      isOpen: false,
    }),
}));