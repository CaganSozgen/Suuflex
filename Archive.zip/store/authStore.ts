import { Creator } from "@prisma/client";
import { create } from "zustand";
import { createJSONStorage, devtools, persist } from "zustand/middleware";

type Status = "authenticated" | "unauthenticated" | "loading";

interface AuthState {
  user: Creator | null;
  status: Status;
  setUser: (user: Creator) => void;
  setStatus: (status: Status) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  devtools(
    persist(
      (set) => ({
        user: null,
        status: "unauthenticated",
        setUser: (user: Creator) =>
          set(() => ({
            user: {
              ...user,
            },
          })),
          setStatus: (status: Status) => {
            set(() => ({
              status,
            }));
          }
        ,
        logout: async () => {
          set(() => ({
            user: null,
            status: "unauthenticated",
          }));
        },
      }),
      {
        name: "user", 
        storage: createJSONStorage(() => localStorage), 
      }
    )
  )
);
