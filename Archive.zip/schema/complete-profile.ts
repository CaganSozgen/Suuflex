import { z } from "zod";

export const completeProfileSchema = z.object({
  walletAddress: z.string().min(1, {
    message: "Wallet address must be valid.",
  }),
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  profileImage: z.string().url({
    message: "Please upload an image.",
  }),
});
