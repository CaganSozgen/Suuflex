import { z } from "zod";

export const CreateVideoSchema = z.object({
  title: z.string().min(1, {
    message: "Title must be at least 1 character.",
  }),
  description: z.string().min(20, {
    message: "Description must be at least 20 character.",
  }),
  url: z.string().min(1, {
    message: "Please provide a valid URL.",
  }).url({
    message: "Please provide a valid URL.",
  }),
  thumbnail: z.string().min(1, {
    message: "Please provide a valid URL.",
  }).url({
    message: "Please provide a valid URL.",
  }),
    cardThumbnail: z.string().min(1, {
    message: "Please provide a valid URL.",
  }).url({
    message: "Please provide a valid URL.",
  }),
  categoryId: z.string().min(1, {
    message: "Please select a category.",
  }),
})