import { z } from "zod";

export const updateVideoSchema = z.object({
  title: z.string(),
  description: z.string(),
  url: z.string(),
  thumbnail: z.string(),
  card_thumbnail: z.string(),
  categoryId: z.string(),
});
