import { z } from "zod";

export const videoGetByTitleSchema = z.object({
  videoTitle: z.string(),
})