import { formatBalance } from "@/lib/utils";
import { getFullnodeUrl, SuiClient } from "@mysten/sui/client";
import { useWallet } from "@suiet/wallet-kit";
import { useEffect, useState } from "react";

const rpcUrl = getFullnodeUrl(
  process.env.NODE_ENV === "development" ? "mainnet" : "mainnet"
);
const client = new SuiClient({ url: rpcUrl });

export const useTokenBalance = (token: string) => {
  const [balance, setBalance] = useState<number>(0);
  const { address, connected } = useWallet();

  useEffect(() => {
    const getBalance = async () => {
      if (address && connected) {
        const clientBalance = await client.getBalance({
          owner: address,
          coinType: token,
        });
        const realBalance = formatBalance(clientBalance);

        setBalance(parseInt(realBalance));
      }
    };

    getBalance();
  }, [address, token, connected]);


  return {
    balance,
  };
};
