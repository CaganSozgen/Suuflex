"use client";
import CommentCard from "@/components/comment-card";
import CreateCommentCard from "@/components/create-comment";
import SendSum from "@/components/send-sum";
import TipWithSui from "@/components/tip-with-sui";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { useTokenBalance } from "@/hooks/useTokenBalance";
import Like from "@/icon/like";
import { videoVote, VoteBody } from "@/lib/mutations/videos/vote/vote";
import { ApiResponse, VideoWithRelations } from "@/lib/types";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import { useAuthStore } from "@/store/authStore";
import { Prisma, VideoVote } from "@prisma/client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader } from "lucide-react";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import ReactPlayer from "react-player/youtube";
import { toast } from "sonner";
import { NumericFormat } from "react-number-format";
import { updateVideo } from "@/lib/mutations/videos/video";

interface Props {
  video: VideoWithRelations;
}

const VideoSection = ({ video }: Props) => {
  const [sendSum, setSendSum] = useState(false);
  const [tipSui, setTipSui] = useState(false);
  const { user } = useAuthStore();

  const queryClient = useQueryClient();

  const { mutate: likeVideo, isPending: isLiking } = useMutation<
    ApiResponse<VideoVote>,
    string,
    VoteBody
  >({
    mutationFn: videoVote,
    mutationKey: ["video-vote", video.id, user?.id],
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["video", video.slug],
      });
    },
  
  });

  const { mutate: handleUpdateVideo } = useMutation<
    ApiResponse<VideoWithRelations>,
    string,
    Prisma.VideoUpdateInput
  >({
    mutationFn: ({ ...body }) => updateVideo({ 
      slug: video.slug,
      ...body
     }),
    mutationKey: ["update-video"],
    onError: (error: string) => {
      toast.error(error);
    },
  });

  useEffect(() => {
    if (video) {
      handleUpdateVideo({
        id: video.id,
        total_views: video.total_views + 1,
      });
    }
  }, [handleUpdateVideo, video]);

  if (!video) {
    return null;
  }

  const userHasVoted = video.videoVote.some(
    (videoVote) => videoVote.voterId === user?.id
  );
  const category = video.category.name;

  return (
    <React.Fragment>
      <SendSum isOpen={sendSum} setIsOpen={setSendSum} video={video} />
      <TipWithSui isOpen={tipSui} setIsOpen={setTipSui} video={video} />
      <div className="flex flex-col items-start w-full gap-8 p-4">
        <div className="player-wrapper">
          <ReactPlayer
            url={video.url}
            className="react-player"
            height="100%"
            width="100%"
            controls={true}
          />
        </div>

        <div className="flex md:flex-row items-start justify-between w-full flex-col gap-4">
          <div className="flex flex-col items-start flex-1 gap-3 ">
            <h1 className={cn(shantell.className, " ty-h5")}>{video.title}</h1>

            <div className="flex items-center gap-2">
              <Image
                src={video.creator.profileImage}
                alt={"logo"}
                height={14}
                width={14}
                className="rounded-full"
              />
              <h1 className={cn(alexandria.className, "ty-descriptions ")}>
                @{video.creator.name}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-4 flex-wrap">
            <Button
              onClick={() =>
                likeVideo({
                  likeOrDislike: "LIKE",
                  slug: video.slug,
                  voterId: user?.id ?? "",
                })
              }
              disabled={userHasVoted}
              className="disabled:bg-white/50 px-4 py-3 flex items-center gap-2 hover:bg-white/20 bg-white/[.08] rounded-lg"
            >
              {isLiking ? (
                <>
                  <Loader
                    className="w-4 h-4 animate-spin"
                    stroke="white"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </>
              ) : (
                <>
                  <Like />
                  <p
                    className={cn(
                      shantell.className,
                      "text-white/50 text-base font-semibold"
                    )}
                  >
                    {video.likes}
                  </p>
                </>
              )}
            </Button>
            <Button
              onClick={() => setSendSum(!sendSum)}
              className={cn(
                "px-4 py-3 rounded-lg text-black bg-white",
                "text-black text-base font-semibold hover:opacity-75 transition-all",
                shantell.className,
                (category === "SuuNews" || category === "SuuEducation") &&
                  "hidden"
              )}
            >
              Send sum $SUU
            </Button>
            <Button
              onClick={() => setTipSui(!tipSui)}
              className={cn(
                "px-4 py-3 rounded-lg text-black bg-blue-100",
                " text-base font-semibold hover:opacity-75 transition-all",
                shantell.className,
                (category === "SuuNews" || category === "SuuEducation") &&
                  "hidden"
              )}
            >
              Tip with $SUI
            </Button>
          </div>
        </div>
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger>Description</AccordionTrigger>
            <AccordionContent className="bg-[#101519]">
              {video.description}
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="flex flex-col items-start justify-start w-full gap-2">
          <h1 className="p-4 rounded-2xl text-white/50">Comments</h1>
          <CreateCommentCard video={video} />
          {video.comments.map((comment, index) => (
            <CommentCard comment={comment} key={index} video={video} />
          ))}
        </div>
      </div>
    </React.Fragment>
  );
};

export default VideoSection;
