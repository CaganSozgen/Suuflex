import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";
import Image from "next/image";
import React from "react";

const TokenomicsSection = () => {
  return (
    <section
      id="tokenomics"
      className="flex flex-col items-center self-stretch"
    >
      <div className="flex container flex-col justify-center items-center gap-16 self-stretch">
        <div className="flex items-center gap-2 self-stretch">
          <p className={cn(shantell.className, "ty-h2 flex-1")}>
            Token Economics
          </p>
        </div>

        <div className="flex flex-col items-center">
          <div className="flex justify-center items-center gap-2">
            <p className={cn(shantell.className, 'text-[32px] font-semibold text-white text-center')}>Suu Tokenomics</p>
          </div>

          <Image
            src={"/assets/tokenomics.png"}
            width={1075}
            height={625}
            alt="tokenomics image"
            className="max-h-[1015px] h-full w-full"
            priority
          />
        </div>
      </div>
    </section>
  );
};

export default TokenomicsSection;