import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import Image from "next/image";
import Link from "next/link";
import React from "react";

const HowToBuySection = () => {

  const images = [
    {
      image: "/assets/hop-24.png",
      href: "https://hop.ag/swap/SUI-USDT",
      name: "Hop Aggregator",
      width: 24,
      height: 24,
    },
    {
      image: "/assets/binance.png",
      href: "https://www.binance.com/en/trade/SUI_USDT",
      name: "Binance",
      width: 24,
      height: 24,
    },
    {
      image: "/assets/bybit.png",
      href: "https://www.bybit.com/trade/spot/SUI/USDT",
      name: "Bybit",
      width: 61.412,
      height: 24,
    },
    {
      image: "/assets/okx.png",
      href: "https://www.okx.com/trade-spot/sui-usdt",
      name: "Okx",
      width: 55,
      height: 24,
    },
  ];

  const steps = [
    {
      stepNumber: "01.",
      title: "Choose a wallet",
      description: "SUI Wallet Preferred",
      elements: () => {
        return (
          <Link
            href={
              "https://chromewebstore.google.com/detail/sui-wallet/opcgpfmipidbgpenhmajoajpbobppdil"
            }
            target="_blank"
            rel="noopener noreferrer"
            className="flex justify-center items-center gap-2 py-3 px-6 rounded-lg ring-[1px] ring-[#233985] bg-[#F0F6FE] hover:scale-[105%] duration-200"
          >
            <Image
              src={"/assets/dashboard/sui.png"}
              width={23}
              height={24}
              alt="SUI"
              className="h-[24px] w-[24px]"
            />

            <p className={cn(shantell.className, "font-bold text-black")}>
              Download Wallet
            </p>
          </Link>
        );
      },
    },
    {
      stepNumber: "02.",
      title: "BUY $SUI",
      description: "You can purchase it on various Exchanges",
      elements: () => {
        const images = [
          {
            image: "/assets/hop-24.png",
            href: "https://hop.ag/swap/SUI-USDT",
            name: "Hop Aggregator",
            width: 24,
            height: 24,
          },
          {
            image: "/assets/binance.png",
            href: "https://www.binance.com/en/trade/SUI_USDT",
            name: "Binance",
            width: 24,
            height: 24,
          },
          {
            image: "/assets/bybit.png",
            href: "https://www.bybit.com/trade/spot/SUI/USDT",
            name: "Bybit",
            width: 61.412,
            height: 24,
          },
          {
            image: "/assets/okx.png",
            href: "https://www.okx.com/trade-spot/sui-usdt",
            name: "Okx",
            width: 55,
            height: 24,
          },
        ];
        return (
          <div className="flex items-center justify-center gap-2 rounded-lg flex-wrap">
            {images.map((image, index) => (
              <Link
              key={index}
                href={image.href}
                target="_blank"
                rel="noopener noreferrer"
              className="flex p-3 justify-center items-start gap-2 rounded-lg ring-[1px] ring-white/[.16] bg-white/[.04]"
            >
                <Image 
                  src={image.image}
                  width={image.width}
                  height={image.height}
                  alt={image.name}
                  className="w-full h-full"
                />
              </Link>
            ))}
          </div>
        );
      },
    },
    {
      stepNumber: "03.",
      title: "BUY $SUU",
      description:
        "We will be listed in HopAggregator for a faster SUU Experience!",
      elements: () => {
        return (
          <Link
            href={
              "https://hop.ag/swap/SUI-0xe49faf3eec344507eaadb6d21119d95823ae48b3540708489d492a5d8d9e79ed::suu::SUU"
            }
            target="_blank"
            rel="noopener noreferrer"
            className="flex justify-center items-center gap-2 py-3 px-6 rounded-lg ring-[1px] ring-[#233985] bg-[#F0F6FE] hover:scale-[105%] duration-200"
          >
            <Image
              src={"/assets/hop-24.png"}
              width={23}
              height={24}
              alt="SUI"
              className="h-[24px] w-[24px]"
            />

            <p className={cn(shantell.className, "font-bold text-black")}>
              BUY NOW
            </p>
          </Link>
        );
      },
    },
  ];
  return (
    <section
      id="how-to-buy"
      className="flex flex-col items-center self-stretch relative min-h-screen"
    >
      <Image
        src={"/assets/how-to-buy.png"}
        width={1440}
        height={1083}
        alt="How To Buy"
        className="-z-20 absolute inset-0 w-full h-full object-cover"
      />
      <div className="flex container flex-col items-start gap-8 self-stretch">
        <div className="flex items-center gap-2 self-stretch">
          <p className={cn(shantell.className, "ty-h2 flex-1 text-white")}>
            How to buy
          </p>
        </div>

        <div className="flex justify-center items-center self-stretch flex-col gap-4 lg:flex-row">
          <div className="flex flex-col w-full">
            <div className="relative flex  p-8 flex-col justify-start items-start gap-4 self-stretch">
              <div className="flex flex-col justify-end items-start gap-4 flex-1">
                <p className={cn(shantell.className, "ty-h1 text-[#F0F6FE]")}>
                  01.
                </p>

                <div className="flex flex-col justify-center items-start gap-2 flex-1">
                  <p className={cn(shantell.className, " ty-h4 text-white")}>
                    Choose a wallet
                  </p>

                  <p
                    className={cn(
                      alexandria.className,
                      "ty-descriptions text-white-72 flex-1 self-stretch"
                    )}
                  >
                    SUI Wallet Preferred
                  </p>
                </div>

                <Link
                  href={
                    "https://chromewebstore.google.com/detail/sui-wallet/opcgpfmipidbgpenhmajoajpbobppdil"
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex justify-center items-center gap-2 py-3 px-6 rounded-lg ring-[1px] ring-[#233985] bg-[#F0F6FE] hover:scale-[105%] duration-200"
                >
                  <Image
                    src={"/assets/dashboard/sui.png"}
                    width={23}
                    height={24}
                    alt="SUI"
                    className="h-[24px] w-[24px]"
                  />

                  <p className={cn(shantell.className, "font-bold text-black")}>
                    Download Wallet
                  </p>
                </Link>
              </div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="226"
                height="193"
                viewBox="0 0 226 193"
                fill="none"
                className="absolute bottom-0 right-0 sm:bottom-0 sm:left-[250px] md:left-[300px] md:bottom-[-50px] lg:bottom-[-7.739px] lg:left-[378px]"
              >
                <path
                  d="M221.572 167.677C222.909 165.543 226.693 161.541 225.415 158.924C223.688 155.391 220.446 158.085 218.354 159.798C214.239 163.165 210.447 170.703 205.648 172.538C207.337 131.638 195.095 92.5795 169.619 60.4697C144.281 28.5324 105.782 1.29797 63.5457 0.537271C42.8734 0.164907 22.2159 5.42854 6.64397 19.8314C5.30774 21.0672 -1.58027 26.8707 1.73353 28.5341C3.46101 29.4014 12.2323 21.8639 14.0075 20.7623C23.2353 15.0349 32.9327 11.2364 43.6042 9.37221C79.9661 3.02042 117.141 20.4392 143.249 44.5166C160.544 60.4665 174.638 80.6539 184.033 102.335C188.883 113.527 192.761 125.421 194.744 137.496C196.417 147.68 199.561 164.367 195.76 174.336C188.723 168.295 187.354 155.156 181.222 148.085C177.974 144.339 172.138 143.426 172.071 149.737C172.016 154.854 177.852 161.768 180.307 166.07C183.047 170.87 185.928 175.554 189.105 180.076C191.435 183.393 195.052 191.482 199.269 192.237C206.727 193.572 217.967 173.037 221.572 167.677C220.068 169.913 222.97 165.446 221.572 167.677Z"
                  fill="#EBF4FF"
                  fill-opacity="0.5"
                />
              </svg>
            </div>

            <div className="relative flex  p-8 flex-col justify-start items-start gap-4 self-stretch sm:justify-center sm:items-center">
              <div className="flex flex-col justify-end items-start gap-4 flex-1">
                <p className={cn(shantell.className, "ty-h1 text-[#F0F6FE]")}>
                  02.
                </p>

                <div className="flex flex-col justify-center items-start gap-2 flex-1">
                  <p className={cn(shantell.className, " ty-h4 text-white")}>
                    BUY $SUI
                  </p>

                  <p
                    className={cn(
                      alexandria.className,
                      "ty-descriptions text-white-72 flex-1 self-stretch"
                    )}
                  >
                    You can purchase it on various Exchanges
                  </p>
                </div>

                <div className="flex items-center justify-center gap-2 rounded-lg flex-wrap">
                  {images.map((image, index) => (
                    <Link
                      key={index}
                      href={image.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex p-3 justify-center items-start gap-2 rounded-lg ring-[1px] ring-white/[.16] bg-white/[.04]"
                    >
                      <Image
                        src={image.image}
                        width={image.width}
                        height={image.height}
                        alt={image.name}
                        className="w-full h-full"
                      />
                    </Link>
                  ))}
                </div>
              </div>

              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="226"
                height="193"
                viewBox="0 0 226 193"
                fill="none"
                className="absolute bottom-0 right-0 md:right-[60px] md:bottom-[-50px] lg:right-[200px] lg:bottom-[-20px] xl:right-[300px]"
              >
                <path
                  d="M221.572 167.677C222.909 165.543 226.693 161.541 225.415 158.924C223.688 155.391 220.446 158.085 218.354 159.798C214.239 163.165 210.447 170.703 205.648 172.538C207.337 131.638 195.095 92.5795 169.619 60.4697C144.281 28.5324 105.782 1.29797 63.5457 0.537271C42.8734 0.164907 22.2159 5.42854 6.64397 19.8314C5.30774 21.0672 -1.58027 26.8707 1.73353 28.5341C3.46101 29.4014 12.2323 21.8639 14.0075 20.7623C23.2353 15.0349 32.9327 11.2364 43.6042 9.37221C79.9661 3.02042 117.141 20.4392 143.249 44.5166C160.544 60.4665 174.638 80.6539 184.033 102.335C188.883 113.527 192.761 125.421 194.744 137.496C196.417 147.68 199.561 164.367 195.76 174.336C188.723 168.295 187.354 155.156 181.222 148.085C177.974 144.339 172.138 143.426 172.071 149.737C172.016 154.854 177.852 161.768 180.307 166.07C183.047 170.87 185.928 175.554 189.105 180.076C191.435 183.393 195.052 191.482 199.269 192.237C206.727 193.572 217.967 173.037 221.572 167.677C220.068 169.913 222.97 165.446 221.572 167.677Z"
                  fill="#EBF4FF"
                  fill-opacity="0.5"
                />
              </svg>
            </div>

            <div className="flex  p-8 flex-col justify-start items-start sm:justify-end sm:items-end gap-4 self-stretch">
              <div className="flex max-w-[360px] flex-col justify-end items-start gap-4 flex-1">
                <p className={cn(shantell.className, "ty-h1 text-[#F0F6FE]")}>
                  03.
                </p>

                <div className="flex flex-col justify-center items-start gap-2 flex-1">
                  <p className={cn(shantell.className, " ty-h4 text-white")}>
                    BUY $SUU
                  </p>

                  <p
                    className={cn(
                      alexandria.className,
                      "ty-descriptions text-white-72 flex-1 self-stretch"
                    )}
                  >
                    We will be listed in HopAggregator for a faster SUU
                    Experience!
                  </p>
                </div>

                <Link
                  href={
                    "https://hop.ag/swap/SUI-0xe49faf3eec344507eaadb6d21119d95823ae48b3540708489d492a5d8d9e79ed::suu::SUU"
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex justify-center items-center gap-2 py-3 px-6 rounded-lg ring-[1px] ring-[#233985] bg-[#F0F6FE] hover:scale-[105%] duration-200"
                >
                  <Image
                    src={"/assets/hop-24.png"}
                    width={23}
                    height={24}
                    alt="SUI"
                    className="h-[24px] w-[24px]"
                  />

                  <p className={cn(shantell.className, "font-bold text-black")}>
                    BUY NOW
                  </p>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowToBuySection;
