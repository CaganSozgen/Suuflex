import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";
import Image from "next/image";
import React from "react";

const RoadmapSection = () => {
  return (
    <section
      id="roadmap"
      className="flex flex-col items-center self-stretch relative"
    >
      <div className="flex container p-8 flex-col items-start gap-8 self-stretch">
        <div className="flex items-center gap-2">
          <p className={cn(shantell.className, "ty-h2 flex-1 text-white")}>
            Roadmap
          </p>
        </div>
      </div>

      <Image
        src={"/assets/dashboard/roadmap.png"}
        width={1425}
        height={1004}
        alt="roadmap image"
        className=" inset-0 w-full h-full"
        priority
      />
    </section>
  );
};

export default RoadmapSection;
