import React from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { alexandria } from "@/public/fonts";
import { VideoWithRelations } from "@/lib/types";
import Link from "next/link";

interface Props {
  other_videos: VideoWithRelations[];
}

const OtherVid = ({ other_videos }: Props) => {


  return (
    <div className="flex flex-col gap-4 m-4 lg:m-0">
      <h1 className={cn(alexandria.className, "ty-subtitle text-white/50")}>
        Upcoming
      </h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-1 gap-4 ">
        {other_videos.slice(0, 10).map((video, index) => {
          return (
            <Link
              href={`/dashboard/${video.slug}`}
              key={index}
              className="flex flex-col gap-2 hover:ring-[.5px] ring-blue-72 p-3 rounded-lg"
            >
              <Image
                src={video.thumbnail}
                alt={video.title}
                width={280}
                height={250}
                className="sm:max-w-[300px] min-h-[160px] max-h-[160px] rounded w-full object-cover"
              />

              <div className="flex flex-col gap-2">
                <div className="flex flex-row gap-1">
                  <Image
                    src={video.creator.profileImage}
                    alt={video.creator.name}
                    height={14}
                    width={14}
                    className="size-[14px] rounded-full"
                  />
                  <h1
                    className={cn(
                      alexandria.className,
                      "ty-subtitle text-white/50"
                    )}
                  >
                    {video.creator.name}
                  </h1>
                </div>
                <h1
                  className={cn(
                    alexandria.className,
                    "ty-subtitle  text-ellipsis line-clamp-2"
                  )}
                >
                  {video.description}
                </h1>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default OtherVid;
