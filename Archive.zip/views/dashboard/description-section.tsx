"use client";

import NowPlaying from "@/components/now-playing";
import { getOtherVideos, getVideo } from "@/lib/queries/videos";
import { useQuery } from "@tanstack/react-query";
import { notFound } from "next/navigation";
import { useEffect } from "react";
import OtherVid from "./other-video";
import VideoSection from "./video-section";

interface Props {
  slug: string;
}
const DescriptionSection = ({ slug }: Props) => {
  const { data: video, isSuccess } = useQuery({
    queryFn: () => getVideo(slug),
    queryKey: ["video", slug],
  });
  const { data: other_videos } = useQuery({
    queryFn: () => getOtherVideos(slug),
    queryKey: ["other-videos", slug],
  });

  useEffect(() => {
    if (!video && isSuccess) {
      return notFound();
    }
  }, [video, isSuccess]);

  if (!video || !other_videos) {
    return null;
  }

  return (
    <div className="flex justify-center items-center pt-[15rem] pb-8">
      <div className="flex flex-col lg:flex-row items-start justify-start grow gap-8 max-w-[1440px]">
        <VideoSection video={video.data} />

        <div className="flex flex-col gap-4 items-start justify-start lg:max-w-[300px] w-full">
          <NowPlaying video={video.data} />
          <OtherVid other_videos={other_videos.data} />
        </div>
      </div>
    </div>
  );
};

export default DescriptionSection;
