import SuuflexIcon from "@/icon/suuflex";
import { socials } from "@/lib/constant";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import Image from "next/image";
import Link from "next/link";



const Onboarding = () => {
  const choices = [
    {
      name: "Adeniyi.sui",
      image: "/assets/onboarding/image-1.jpg",
    },
    {
      name: "Kotaro.sui",
      image: "/assets/onboarding/image-2.jpg",
    },
    {
      name: "Matteo.sui",
      image: "/assets/onboarding/image-3.jpg",
    },
  ];



  return (
    <div className="flex flex-col lg:flex-row md:h-screen relative">
      {/* Left side - fixed on large screens, scrollable on small screens */}

      <Image
        src={"/assets/cube.png"}
        alt={"cube"}
        height={600}
        width={600}
        priority
        className="md:absolute top-0 -right-32 md:-right-20 lg:right-0 fixed w-auto max-w-[400px] h-full"
      />

      <div className="w-full lg:w-1/2 p-8 md:p-16 lg:p-32 flex flex-col justify-center items-start gap-8 lg:gap-16">
        <div className="flex flex-col items-start gap-4 lg:gap-8 self-stretch">
          <SuuflexIcon className="w-[200px] h-[93px] lg:w-[275px] lg:h-[128px]" />
          <p
            className={cn(
              alexandria.className,
              "ty-subheading text-white/50 text-sm lg:text-base"
            )}
          >
            One and only video streaming platform made on top of Sui Network.
          </p>

          <div className="flex items-center gap-2 w-full">
            {socials.map((social, index) => (
              <Link
                href={social.href}
                target={social.isExternal ? "_blank" : "_self"}
                rel="noopener noreferrer"
                key={index}
                className="p-2 flex items-center gap-2 self-stretch"
              >
                {social.icon}
              </Link>
            ))}
          </div>
        </div>
        <h5
          className={cn(
            shantell.className,
            "ty-h5 text-white text-lg lg:text-xl"
          )}
        >
          Select your suuuuupahuser
        </h5>
      </div>

      {/* Right side - scrollable on all screen sizes */}
      <div className="w-full  lg:w-1/2 max-h-screen lg:overflow-y-auto b relative">
        <div className="p-8 md:p-16 lg:p-32 flex flex-col items-center gap-8 bg-white/[.04]">
          {choices.map((data, index) => (
            <Link
              href="/dashboard"
              key={index}
              className="w-full max-w-[300px] flex p-4 flex-col items-center gap-4 rounded-[32px] hover:ring-2 hover:ring-blue-100 bg-white/[.04] backdrop-blur-[64px] duration-200"
            >
              <Image
                src={data.image}
                alt={data.name}
                height={256}
                width={256}
                className="rounded-lg w-full h-full object-cover"
              />
              <h1
                className={cn(shantell.className, "ty-h6 text-base lg:text-lg")}
              >
                {data.name}
              </h1>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
