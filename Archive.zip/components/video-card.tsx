import { VideoWithRelations } from '@/lib/types'
import { cn } from '@/lib/utils'
import { alexandria, shantell } from '@/public/fonts'
import { Video } from '@prisma/client'
import Image from 'next/image'
import Link from 'next/link'
import React from 'react'

interface Props {
  video: VideoWithRelations
};


const VideoCard = ({video}:Props) => {
  return (
    <Link
      href={`/dashboard/${video.slug}`}
      className="flex p-4 flex-col items-start gap-4 rounded-2xl hover:ring-1 hover:ring-blue-100 bg-white/[.04] hover:cursor-pointer shrink-0 overflow-hidden"
    >
      <Image
        src={video.card_thumbnail ?? video.thumbnail}
        alt="Video media"
        width={200}
        height={300}
        priority
        className="w-full object-cover flex aspect-[9/16] max-h-[300px] h-auto flex-col justify-center items-center rounded-lg bg-white/[.04] shrink-0"
      />

      <div className="flex flex-col items-start w-full gap-2">
        <div className="flex items-center gap-2 ">
          <Image
            src={video.creator.profileImage}
            alt="Test"
            height={14}
            width={14}
            className="w-full h-full max-w-[14px] max-h-[14px] rounded-lg size-14 object-cover"
          />
          <p className={cn(alexandria.className, "ty-subtitle text-white/50")}>
            @{video.creator.name}
          </p>
        </div>
        <h6
          className={cn(
            shantell.className,
            "ty-h6 text-white line-clamp-2 break-words w-full"
          )}
        >
          {video.title}
        </h6>
      </div>
    </Link>
  );
}

export default VideoCard