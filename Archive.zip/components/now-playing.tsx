"use client";

import { VideoWithRelations } from "@/lib/types";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import Image from "next/image";

interface Props {
  video: VideoWithRelations;
}
const NowPlaying = ({ video }: Props) => {
  return (
    <div className="flex flex-col lg:items-start items-center gap-4 self-stretch">
      <p className={cn(shantell.className, "ty-h6 text-blue-100 pl-0 lg:pl-3")}>
        Now playing
      </p>

      <div className="flex flex-col gap-2 p-3 rounded-lg">
        <Image
          src={video.thumbnail}
          alt={video.title}
          width={280}
          height={250}
          className="lg:max-w-[300px] min-h-[160px] lg:max-h-[160px] rounded w-full object-cover"
        />

        <div className="flex flex-col gap-2">
          <div className="flex flex-row gap-1">
            <Image
              src={video.creator.profileImage}
              alt={"DP"}
              height={14}
              width={14}
              className="rounded-full"
            />
            <h1
              className={cn(alexandria.className, "ty-subtitle text-white/50")}
            >
              @{video.creator.name}
            </h1>
          </div>
          <h1 className={cn(alexandria.className, "ty-subtitle  min-h-[48px]")}>
            {video.title}
          </h1>
        </div>
      </div>
    </div>
  );
};

export default NowPlaying;

// <div className="flex flex-col gap-4 w-full m-4">
//     <h1 className={cn(alexandria.className, "ty-subtitle text-blue-100")}>
//       Now playing
//     </h1>
//     <div className="flex flex-col gap-2 p-3 hover:ring-[0.5px] hover:ring-blue-72 w-full rounded-lg">
//       <Image
//         src={video.thumbnail}
//         alt={video.title}
//         width={280}
//         height={250}
//         className="max-w-[300px] min-h-[160px] max-h-[160px] rounded w-full object-cover"
//       />
//       <div className="flex flex-col gap-2">
//         <div className="flex flex-row gap-1">
//           <Image
//             src={video.creator.profileImage}
//             alt={"DP"}
//             height={14}
//             width={14}
//             className="rounded-full"
//           />
//           <h1
//             className={cn(alexandria.className, "ty-subtitle text-white/50")}
//           >
//             @{video.creator.name}
//           </h1>
//         </div>
//         <h1 className={cn(alexandria.className, "ty-subtitle  min-h-[48px]")}>
//           {video.title}
//         </h1>
//       </div>
//     </div>
//   </div>
