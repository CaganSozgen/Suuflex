// 'use client';

// import { Input } from "@/components/ui/input";
// import { getVideo } from "@/lib/queries/videos";
// import { useQuery } from "@tanstack/react-query";
// import React from "react";
// import { useDebounce } from "react-use";
// import SearchedVideos from "../searched-videos";


// const GetByIdVideo =  () => {
//   const [state, setState] = React.useState("Typing stopped");
//   const [val, setVal] = React.useState("");
//   const [debouncedValue, setDebouncedValue] = React.useState("");

//   const [, cancel] = useDebounce(
//     () => {
//       setState("Typing stopped");
//       setDebouncedValue(val);
//     },
//     2000,
//     [val]
//   );

//   const { data: videos } = useQuery({
//     queryFn: () => getVideo(debouncedValue),
//     queryKey: ["video", debouncedValue],
//     enabled: !!debouncedValue,
//   });

  

//   return (
//     <div>
//       <Input
//         type="text"
//         value={val}
//         placeholder="Debounced input"
//         onChange={({ currentTarget }) => {
//           setState("Waiting for typing to stop...");
//           setVal(currentTarget.value);
//         }}
//       />
//       <div>{state}</div>
//       <div>
//         Debounced value: {debouncedValue}
//         <button onClick={cancel}>Cancel debounce</button>
//       </div>

//       {
//         videos && videos.length > 0 && (
//           <SearchedVideos videos={videos} />
//         )
//       }

//     </div>
//   );
// };

// export default GetByIdVideo;
