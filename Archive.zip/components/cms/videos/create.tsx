"use client";

import { CreateVideoSchema } from "@/schema/videos/create";
import { zodResolver } from "@hookform/resolvers/zod";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import slugify from "slugify";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Link from "next/link";
import { useMutation, useQuery } from "@tanstack/react-query";
import { getCategories } from "@/lib/queries/categories";
import { UploadDropzone } from "@/lib/uploadthing";
import Image from "next/image";
import { Loader } from "lucide-react";
import { createVideo } from "@/lib/mutations/videos/video";
import { Prisma, Video } from "@prisma/client";
import { useAuthStore } from "@/store/authStore";
import { ApiResponse } from "@/lib/types";
import { toast } from "sonner";

const CreateVideo = () => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [cardThumbnailUrl, setCardThumbnailUrl] = useState<string | null>(null);

  const [isUploading, setIsUploading] = useState(false);
  const [isCardThumbnailUploading, setIsCardThumbnailUploading] = useState(false);
  const { user } = useAuthStore();

  const { data: categories } = useQuery({
    queryFn: () => getCategories(),
    queryKey: ["categories"],
  });

  const { mutate: uploadVideo, isPending: uploadingVideo } = useMutation<
    ApiResponse<Video>,
    string,
    Prisma.VideoCreateInput
  >({
    mutationFn: ({ ...body }: Prisma.VideoCreateInput) =>
      createVideo({ ...body }),
    mutationKey: ["create-video"],
    onSuccess: ({message}) => {
      toast.success(message);
      form.reset();
    },
    onError: (error) => {
      toast.error(error);
    },
  });

  const form = useForm<z.infer<typeof CreateVideoSchema>>({
    resolver: zodResolver(CreateVideoSchema),
    defaultValues: {
      title: "",
      description: "",
      url: "",
      thumbnail: "",
      cardThumbnail:"",
      categoryId: "",
    },
  });

  function onSubmit(values: z.infer<typeof CreateVideoSchema>) {
    uploadVideo({
      slug: slugify(values.title),
      category: {
        connect: {
          id: values.categoryId,
        },
      },
      description: values.description,
      title: values.title,
      url: values.url,
      thumbnail: values.thumbnail,
      creator: {
        connect: {
          id: user?.id,
        },
      },
    });
  }

  return (
    <div className="flex flex-col items-start self-stretch gap-4 p-4">
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="w-full space-y-4"
        >
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Video Title (required)</FormLabel>
                <FormControl>
                  <Input placeholder="Introducing the SuiPlay0X1" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description (required)</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Sui is a first-of-its-kind Layer 1 blockchain..."
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="url"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Youtube URL (required)</FormLabel>
                <FormControl>
                  <Input placeholder="https://youtube.com/1234" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="thumbnail"
            render={() => (
              <FormItem>
                <FormLabel>Thumbnail (required)</FormLabel>
                <FormControl className="border border-white/50 rounded border-dashed h-full p-2 -z-10 max-h-[400px] max-w-[500px] w-full overflow-hidden">
                  {imageUrl ? (
                    <Image
                      src={imageUrl}
                      width={500}
                      height={400}
                      alt="thumbnail"
                      className="object-cover w-full h-full rounded-lg"
                    />
                  ) : isUploading ? (
                    <div className="w-full h-[400px] grid place-content-center">
                      <Loader
                        className="w-6 h-6 animate-spin"
                        stroke="white"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </div>
                  ) : (
                    <UploadDropzone
                      endpoint="imageUploader"
                      appearance={{
                        button: "hidden",
                        uploadIcon: "hidden",
                      }}
                      config={{
                        appendOnPaste: true,
                        mode: "auto",
                      }}
                      onUploadBegin={() => {
                        setIsUploading(true);
                      }}
                      onClientUploadComplete={(url) => {
                        setImageUrl(url[0].url);
                        form.setValue("thumbnail", url[0].url);
                        setIsUploading(false);
                      }}
                    />
                  )}
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="cardThumbnail"
            render={() => (
              <FormItem>
                <FormLabel>Card Thumbnail (required)</FormLabel>
                <FormControl className="border border-white/50 rounded border-dashed h-full p-2 -z-10 max-h-[400px] max-w-[500px] w-full overflow-hidden">
                  {cardThumbnailUrl ? (
                    <Image
                      src={cardThumbnailUrl}
                      width={500}
                      height={400}
                      alt="cardThumbnail"
                      className="object-cover w-full h-full rounded-lg"
                    />
                  ) : isCardThumbnailUploading ? (
                    <div className="w-full h-[400px] grid place-content-center">
                      <Loader
                        className="w-6 h-6 animate-spin"
                        stroke="white"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </div>
                  ) : (
                    <UploadDropzone
                      endpoint="imageUploader"
                      appearance={{
                        button: "hidden",
                        uploadIcon: "hidden",
                      }}
                      config={{
                        appendOnPaste: true,
                        mode: "auto",
                      }}
                      onUploadBegin={() => {
                        setIsCardThumbnailUploading(true);
                      }}
                      onClientUploadComplete={(url) => {
                        setCardThumbnailUrl(url[0].url);
                        form.setValue("cardThumbnail", url[0].url);
                        setIsCardThumbnailUploading(false);
                      }}
                    />
                  )}
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="categoryId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Category</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {categories &&
                      categories.data.map((category) => (
                        <SelectItem
                          value={category.id}
                          key={category.id}
                          onClick={() => field.onChange(category.id)}
                        >
                          {category.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button
            type="submit"
            onClick={form.handleSubmit(onSubmit)}
            className="w-full mt-4 bg-blue-100"
          >
            {uploadingVideo ? (
              <Loader
                className="w-6 h-6 animate-spin"
                stroke="white"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            ) : (
              "Upload Video"
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
};

export default CreateVideo;
