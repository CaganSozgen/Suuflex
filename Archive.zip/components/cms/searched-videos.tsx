import { VideoWithRelations } from '@/lib/types';

interface Props {
  videos: VideoWithRelations[]  
}



const SearchedVideos =  ({videos}:Props) => {

  
  
  return (
    <div>SearchedVideos</div>
  )
}

export default SearchedVideos