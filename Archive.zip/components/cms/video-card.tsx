import { Video } from '@prisma/client'
import Image from 'next/image';
import Link from 'next/link';
import React from 'react'

interface Props {
  video:Video
}
const VideoCard = ({video}:Props) => {
  return (
    <Link
    href={`/dashboard/${video.slug}`}
    >
      <Image
        src={video.thumbnail}
        alt={"dashboard"}
        height={500}
        width={500}
        className="max-h-[200px]  min-h-[200px] w-full h-full rounded-lg object-cover"
      />
    </Link>
  );
}

export default VideoCard