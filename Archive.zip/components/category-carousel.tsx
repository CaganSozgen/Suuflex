"use client";
import React from "react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import Image from "next/image";
import { Video } from "@prisma/client";
import Link from "next/link";
import { VideoWithRelations } from "@/lib/types";
import VideoCard from "./video-card";

interface Props {
  category: string;
  videos: VideoWithRelations[] | undefined;
  viewAll: boolean;
  inSection?: boolean;
}

const CategorySection = ({ category, videos, viewAll, inSection }: Props) => {
  return (
    <section id={category} className="flex flex-col items-center self-stretch">
      <div className="container flex flex-col items-start self-stretch gap-8">
        {/* category heading */}

        <div className="flex flex-wrap items-center self-stretch gap-2">
          <h3 className={cn(shantell.className, "flex-1 text-white ty-h3")}>
            {category}
          </h3>

          {viewAll ? (
            <Link
              href={`/category/${category}`}
              className={cn(
                shantell.className,
                "flex px-4 py-3 justify-center items-center gap-2"
              )}
            >
              View All
            </Link>
          ) : null}
        </div>

        {/* category videos */}
        <div
          className={cn(
            "w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 justify-center",
            inSection && 'xl:grid-cols-5'
          )}
        >
          {videos &&
            videos.map((video) => <VideoCard key={video.id} video={video} />)}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
