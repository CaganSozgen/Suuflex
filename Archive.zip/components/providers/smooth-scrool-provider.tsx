"use client";
import { ReactLenis } from "@studio-freight/react-lenis";
import { usePathname } from "next/navigation";
import React from "react";

interface Props {
  children: React.ReactNode;
  disabledPage: string[];
}
const SmoothScroll = ({ children,disabledPage }: Props) => {

  const pathname = usePathname();
  if(disabledPage.includes(pathname)) return <>{children}</>;
  
  return <ReactLenis root>{
    <>
      {children}
    </>
  }</ReactLenis>;
};

export default SmoothScroll;
