"use client";

import { useEffect, useState } from "react";
import VerifyAccountModal from "../modals/account-modal";
import ProfileEditModal from "../profile";

const ModalProvider = () => {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return null;

  return (
    <>
      <VerifyAccountModal />
      <ProfileEditModal />
    </>
  );
};

export default ModalProvider;
