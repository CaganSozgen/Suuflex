"use client";

import React, { PropsWithChildren } from "react";
import { WalletProvider as Provider, SuiWallet } from "@suiet/wallet-kit";
import "@suiet/wallet-kit/style.css";

const WalletProvider = ({ children }: PropsWithChildren) => {
  return <Provider defaultWallets={[SuiWallet]}>{children}</Provider>;
};

export default WalletProvider;
