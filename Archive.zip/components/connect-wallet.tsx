"use client";

import React from "react";
import { useWallet } from "@suiet/wallet-kit";
import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";
import { toast } from "sonner";
import { Button } from "./ui/button";

export function Connectwallet() {
  const {
    select, // select
    configuredWallets,
  } = useWallet();

  return [...configuredWallets].map((wallet) => {
    return (
      <button
        key={wallet.name}
        onClick={() => {
          if (!wallet.installed) {
            toast.error("Please install Sui Wallet to get started.", {
              style: {
                backgroundColor: "#FF4B00",
              },
            });
          }

          select(wallet.name);
        }}
        className={cn(
          shantell.className,
          "flex p-4 justify-center items-center gap-2 ring-[1px] ring-blue-100 w-full"
        )}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M15 15C15 15.8284 15.6716 16.5 16.5 16.5C17.3284 16.5 18 15.8284 18 15C18 14.1716 17.3284 13.5 16.5 13.5C15.6716 13.5 15 14.1716 15 15Z"
            stroke="#EBF4FF"
            strokeWidth="1.5"
          />
          <path
            d="M15.0038 7.80281C9.57619 7.42671 5.1047 6.62133 3 6V15.0614C3 17.0558 3 18.053 3.61958 18.8663C4.23916 19.6796 5.08923 19.9093 6.78937 20.3687C9.53623 21.1109 12.4235 21.5529 15.0106 21.8057C17.6919 22.0677 19.0325 22.1987 20.0163 21.2997C21 20.4007 21 18.9566 21 16.0682V14.0546C21 11.2497 21 9.8473 20.1929 8.97688C19.3859 8.10646 17.9252 8.00524 15.0038 7.80281Z"
            stroke="#EBF4FF"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M17.6258 8C18.0035 6.57673 18.3453 3.98822 17.327 2.70292C16.6816 1.88827 15.7223 1.96654 14.7818 2.04926C9.83791 2.48406 6.34544 3.36731 4.39301 3.96737C3.55348 4.2254 3 5.04522 3 5.96044"
            stroke="#EBF4FF"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
        </svg>
        <p className={cn(shantell.className,'font-semibold text-white')}>Connect Wallet</p>
      </button>
    );
  });
}
