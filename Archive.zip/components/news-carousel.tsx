"use client";

import { fetchTweets, TweetMeta } from "@/lib/queries/tweets";
import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";
import { useQuery } from "@tanstack/react-query";
import { ArrowUp } from "lucide-react";
import { Tweet } from "react-tweet";
import { Button } from "./ui/button";
import { ApiResponse } from "@/lib/types";

interface Props {
  tweets: ApiResponse<TweetMeta> | undefined;
  header: string;
}

const NewsCarousel = ({ tweets, header }: Props) => {
  if (!tweets) {
    return null;
  }

  return (
    <section
      id={"SuuNews-on-X"}
      className="flex flex-col items-center self-stretch"
    >
      <div className="container flex flex-col items-start self-stretch gap-8">
        <div className="flex items-center justify-between flex-1 w-full">
          <h1 className={cn(shantell.className, "ty-h3 sm:w-full")}>
            {header}
          </h1>

          <Button
            variant={"outline"}
            onClick={() => {
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          >
            <ArrowUp size={16} />
          </Button>
        </div>
        {tweets.data.meta.result_count === 0 ? (
          <div className="flex justify-center w-full flex1">
            <p className={cn(shantell.className, "text-center ty-h5")}>
              Start posting your thoughts on X with the hashtag {header}
            </p>
          </div>
        ) : (
          <div className="grid justify-center w-full grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {tweets.data.tweets.map((tweet) => (
              <Tweet id={tweet.id} key={tweet.id} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default NewsCarousel;
