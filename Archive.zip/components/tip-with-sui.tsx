"use client";

import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import { useEffect, useState } from "react";

import { useTokenBalance } from "@/hooks/useTokenBalance";
import { ADMIN_WALLET, SUI_COIN_TYPE } from "@/lib/constant";
import { addTip } from "@/lib/mutations/tips/tips";
import { VideoWithRelations } from "@/lib/types";
import { getFullnodeUrl, SuiClient } from "@mysten/sui/client";
import { Transaction } from "@mysten/sui/transactions";
import { MIST_PER_SUI } from "@mysten/sui/utils";
import { useWallet } from "@suiet/wallet-kit";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader } from "lucide-react";
import { toast } from "sonner";
import { Button } from "./ui/button";
import { NumericFormat } from "react-number-format";
import numeral from "numeral";
interface ITipWithSui {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  video: VideoWithRelations;
}

const rpcUrl = getFullnodeUrl(
  process.env.NODE_ENV === "development" ? "devnet" : "mainnet"
);
const client = new SuiClient({ url: rpcUrl });

const TipWithSui = ({ isOpen, setIsOpen, video }: ITipWithSui) => {
  const { signAndExecuteTransaction, address, connected, on, status } =
    useWallet();

  const { balance: suiBalance } = useTokenBalance(SUI_COIN_TYPE);
  const [tipAmount, setTipAmount] = useState(0);

  const queryClient = useQueryClient();

  const { mutate: tipVideo, isPending } = useMutation({
    mutationFn: addTip,
    mutationKey: ["add-tip"],
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["video", video.slug],
      });

      setIsOpen(false);
      setTipAmount(0);
      toast.success("Video tipped successfully");
    },
    onError: (error: string) => {
      toast.error(error);
    },
  });

  const sendSui = async () => {
    try {
      const tx = new Transaction();

      const mistAmount = tipAmount * Number(MIST_PER_SUI);

      const [coin] = tx.splitCoins(tx.gas, [mistAmount]);

      tx.transferObjects([coin], ADMIN_WALLET);

      const result = await signAndExecuteTransaction({
        transaction: tx,
      });

      const digest = await client.waitForTransaction({ digest: result.digest });

      if (digest && address) {
        tipVideo({
          walletAddress: address,
          tipAmount: tipAmount,
          videoId: video.id,
          ticker: "SUI",
        });
      }
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      }
    }
  };

  const supportersCount = new Set(video.tips.map((tip) => tip.tipperId)).size;



  if (!isOpen) return null;
  return (
    <div className="fixed top-0 left-0 flex justify-center items-center h-full w-full backdrop-blur-lg bg-black/50 z-[999] p-4">
      <div className="flex flex-col gap-4 items-center w-fit rounded-2xl border border-white/[.08] bg-black/100 p-4">
        <div className="flex flex-col w-full gap-2">
          <h1 className={cn(shantell.className, " ty-h6")}>Tip with $SUI</h1>
          <h1
            className={cn(
              alexandria.className,
              "ty-descriptions text-white/50"
            )}
          >
            Spreading suuuum luv &lt;3
          </h1>
        </div>
        <div className="flex flex-col items-center justify-center p-4 sm:flex-row grow">
          <div className="flex flex-col gap-2 p-2 items-center justify-center min-w-[154.5px]">
            <h1 className={cn(shantell.className, " ty-h5")}>
              {numeral(video.total_tips).format("0a")}
            </h1>

            <p
              className={cn(alexandria.className, "text-white/50 ty-subtitle")}
            >
              $SUI received
            </p>
          </div>
          <div className="flex flex-col gap-2 p-2 items-center justify-center min-w-[154.5px]">
            <h1 className={cn(shantell.className, " ty-h5")}>
              {supportersCount}
            </h1>

            <p
              className={cn(alexandria.className, "text-white/50 ty-subtitle")}
            >
              Suuuupporters
            </p>
          </div>
        </div>

        <div className="px-4 py-3 flex flex-row gap-2 items-center rounded-2xl border border-white/[.16] w-full">
          <NumericFormat
            defaultValue={100000}
            value={tipAmount}
            allowLeadingZeros={false}
            thousandSeparator=","
            onValueChange={(values) => {
              setTipAmount(values.floatValue ?? 100000);
            }}
            className="w-full"
          />
          <h1 className={cn(alexandria.className, "ty-title ")}>$SUI</h1>
        </div>

        <div className="flex flex-wrap items-center justify-between w-full gap-2">
          <Button
            onClick={() => setIsOpen(false)}
            className={cn(
              shantell.className,
              "rounded-lg bg-white/[.08] hover:bg-white/80 py-3 px-4 text-white text-base font-semibold"
            )}
          >
            Cancel :(
          </Button>
          <Button
            disabled={tipAmount > suiBalance || tipAmount <= 0 || isPending}
            onClick={() => {
              sendSui();
            }}
            className={cn(
              shantell.className,
              "rounded-lg bg-blue-100 py-3 px-4  text-base font-semibold"
            )}
          >
            {isPending ? (
              <Loader
                className="w-4 h-4 animate-spin"
                stroke="white"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            ) : (
              "Tip with $SUI"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TipWithSui;
