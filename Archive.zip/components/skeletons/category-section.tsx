import React from "react";
import { Skeleton } from "../ui/skeleton";

const CategorySectionSkeleton = () => {
  return (
    <div className="flex flex-col items-center self-stretch w-full">
      <div className="flex flex-col items-start gap-8 self-stretch">
        <div className="flex items-center gap-2 self-stretch justify-between">
          <Skeleton className="h-[46px] w-[250px]" />
          <Skeleton className="h-[46px] w-[100px]" />
        </div>

        <div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 justify-center">
          <Skeleton className="h-[465px] w-full 2xl:w-[256px]" />
          <Skeleton className="h-[465px] w-full 2xl:w-[256px]" />
          <Skeleton className="h-[465px] w-full 2xl:w-[256px]" />
          <Skeleton className="h-[465px] w-full 2xl:w-[256px]" />
        </div>
      </div>
    </div>
  );
};

export default CategorySectionSkeleton;
