import prisma from '@/lib/db';
import { Creator } from '@prisma/client';
import React from 'react'

interface Props {
  user: Creator
}

const ViewedVideos =  ({user}:Props) => {


  return (
    <div>{JSON.stringify(user,null,2)}</div>
  )
}

export default ViewedVideos;

