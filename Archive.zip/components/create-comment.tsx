"use client";

import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import { addressEllipsis, useWallet } from "@suiet/wallet-kit";
import Image from "next/image";
import React, { useState } from "react";
import { Textarea } from "./ui/textarea";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { submitComment } from "@/lib/mutations/comments/comment";
import { useAuthStore } from "@/store/authStore";
import { Video } from "@prisma/client";
import { Loader } from "lucide-react";

interface Props {
  video: Video;
}
const CreateCommentCard = ({ video }: Props) => {
  const [text, setText] = useState("");
  const { address, connected } = useWallet();
  const { user } = useAuthStore();

  const queryClient = useQueryClient();

  function handleTextChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setText(e.target.value);
  }

  const { mutate: createComment, isPending: isCommenting } = useMutation({
    mutationFn: () =>
      submitComment({
        creatorId: user?.id ?? "",
        text,
        videoId: video.id,
      }),
    mutationKey: ["comment", video.id],
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["video", video.slug],
      });
      setText("");
    },
  });

  return (
    <div className="flex flex-row gap-3 items-start rounded-2xl border border-white/[.08] p-4 w-full">
      <Image
        src={user?.profileImage || ""}
        alt={"logo"}
        height={14}
        width={14}
        className="rounded-full"
      />
      <div className="flex flex-col items-start w-full gap-4">
        {connected && address && (
          <h1
            className={cn(
              alexandria.className,
              "text-white/[.72] ty-descriptions"
            )}
          >
            @{addressEllipsis(address)} (you)
          </h1>
        )}

        <Textarea
          value={text}
          placeholder="What are your thoughts hmmm..."
          onChange={handleTextChange}
          className="disabled:cursor-auto"
        />
        <div className="flex items-center justify-end w-full">
          <button
            disabled={!connected || !address || !text}
            onClick={() => {
              createComment();
            }}
            className={cn(
              shantell.className,
              "text-[10px] font-semibold rounded text-white/50 bg-white/[.08] hover:text-black hover:bg-white px-2 py-[6px] ease-out duration-300 disabled:cursor-not-allowed disabled:opacity-50"
            )}
          >
            {isCommenting ? (
              <Loader
                className="w-4 h-4 animate-spin"
                stroke="white"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            ) : (
              "Comment"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateCommentCard;
