import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { updateVideo } from "@/lib/mutations/videos/video";
import { getCategories } from "@/lib/queries/categories";
import { ApiResponse, VideoWithRelations } from "@/lib/types";
import { updateVideoSchema } from "@/schema/videos/update";
import { useAuthModal } from "@/store/modal";
import { zodResolver } from "@hookform/resolvers/zod";
import { Prisma } from "@prisma/client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Modal } from "../ui/modal";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { UploadDropzone } from "@/lib/uploadthing";
import { Loader, X } from "lucide-react";
import Image from "next/image";
import { toast } from "sonner";
import { set } from "date-fns";
import { ScrollArea } from "../ui/scroll-area";

interface Props {
  videoToEdit: VideoWithRelations;
  setVideoToEdit: React.Dispatch<
    React.SetStateAction<VideoWithRelations | undefined | null>
  >;
}
const UpdateVideoModal = ({ videoToEdit, setVideoToEdit }: Props) => {
  const { isOpen, onClose, onOpen } = useAuthModal();
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [cardThumbnailUrl, setCardThumbnailUrl] = useState<string | null>(null);
  
  const [isUploading, setIsUploading] = useState(false);
  const [isCardThumbnailUploading, setIsCardThumbnailUploading] = useState(false);

  const { data: categories } = useQuery({
    queryFn: getCategories,
    queryKey: ["category"],
  });

  const queryClient = useQueryClient();

  const { mutate: handleUpdateVideo } = useMutation<
    ApiResponse<VideoWithRelations>,
    string,
    Prisma.VideoUpdateInput
  >({
    mutationFn: ({ ...body }) => updateVideo({ ...body }),
    mutationKey: ["update-video"],
    onSuccess: () => {
      toast.success("Video updated successfully");
      queryClient.invalidateQueries({
        queryKey: ["video", videoToEdit.slug],
      });
        queryClient.invalidateQueries({
          queryKey: ["videos"],
        });
    },
    onError: (error: string) => {
      toast.error(error);
    }
  });

  // 1. Define your form.
  const form = useForm<z.infer<typeof updateVideoSchema>>({
    resolver: zodResolver(updateVideoSchema),
    defaultValues: {
      title: videoToEdit.title,
      description: videoToEdit.description,
      url: videoToEdit.url,
      thumbnail: videoToEdit.thumbnail,
      card_thumbnail: videoToEdit.card_thumbnail ?? "",
    },
  });

  // 2. Define a submit handler.
  function onSubmit(values: z.infer<typeof updateVideoSchema>) {
    // Do something with the form values.
    // ✅ This will be type-safe and validated.

    handleUpdateVideo({
      ...values,
      slug: videoToEdit.slug,
    });

    setVideoToEdit(null);
  }

  useEffect(() => {
    if (videoToEdit) {
      setImageUrl(videoToEdit.thumbnail);
      setCardThumbnailUrl(videoToEdit.card_thumbnail ?? "");
      form.setValue("title", videoToEdit.title);
      form.setValue("description", videoToEdit.description);
      form.setValue("url", videoToEdit.url);
      form.setValue("thumbnail", videoToEdit.thumbnail);
      form.setValue("categoryId", videoToEdit.categoryId);
      form.setValue("card_thumbnail", videoToEdit.card_thumbnail ?? "");
      onOpen();
    }

    return () => {
      onClose();
    };
  }, [videoToEdit, onOpen, setVideoToEdit, onClose, form]);

  return (
    <Modal
      title={`Edit ${videoToEdit.title}`}
      description=""
      isOpen={isOpen}
      onClose={onClose}
    >
      <ScrollArea className="h-[650px] w-full ">
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-3 p-4"
          >
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder={videoToEdit.title} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input placeholder={videoToEdit.description} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>URL</FormLabel>
                  <FormControl>
                    <Input placeholder={videoToEdit.url} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {categories && categories.data.length > 0 && (
              <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Categories</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue
                            placeholder={videoToEdit.category.name}
                          />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.data.map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="thumbnail"
              render={() => (
                <FormItem>
                  <FormLabel>Thumbnail</FormLabel>
                  <FormControl className="h-full p-2 border border-dashed rounded border-white/50">
                    <div className="relative">
                      {imageUrl && (
                        <X
                          onClick={() => setImageUrl(null)}
                          className="absolute top-0 right-0 z-10 w-4 h-4 -m-2 bg-red-300 rounded-full cursor-pointer"
                        />
                      )}

                      {imageUrl ? (
                        <div className="relative w-full h-full">
                          <Image
                            src={imageUrl}
                            width={400}
                            height={350}
                            alt="thumbnail"
                            className="object-cover w-full h-full overflow-hidden rounded max-h-[200px]"
                          />
                        </div>
                      ) : isUploading ? (
                        <div className="w-full h-[250px] grid place-content-center">
                          <Loader
                            className="w-6 h-6 animate-spin"
                            stroke="white"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </div>
                      ) : (
                        <UploadDropzone
                          endpoint="imageUploader"
                          appearance={{
                            button: "hidden",
                            uploadIcon: "hidden",
                          }}
                          config={{
                            appendOnPaste: true,
                            mode: "auto",
                          }}
                          onUploadBegin={() => {
                            setIsUploading(true);
                          }}
                          onClientUploadComplete={(url) => {
                            setImageUrl(url[0].url);
                            form.setValue("thumbnail", url[0].url);
                            setIsUploading(false);
                          }}
                        />
                      )}
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="card_thumbnail"
              render={() => (
                <FormItem>
                  <FormLabel>Card Thumbnail</FormLabel>
                  <FormControl className="h-full p-2 border border-dashed rounded border-white/50">
                    <div className="relative">
                      {cardThumbnailUrl && (
                        <X
                          onClick={() => setCardThumbnailUrl(null)}
                          className="absolute top-0 right-0 z-10 w-4 h-4 -m-2 bg-red-300 rounded-full cursor-pointer"
                        />
                      )}

                      {cardThumbnailUrl ? (
                        <div className="relative w-full h-full">
                          <Image
                            src={cardThumbnailUrl}
                            width={400}
                            height={350}
                            alt="card_thumbnail"
                            className="object-cover w-full h-full overflow-hidden rounded"
                          />
                        </div>
                      ) : isCardThumbnailUploading ? (
                        <div className="w-full h-[250px] grid place-content-center">
                          <Loader
                            className="w-6 h-6 animate-spin"
                            stroke="white"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </div>
                      ) : (
                        <UploadDropzone
                          endpoint="imageUploader"
                          appearance={{
                            button: "hidden",
                            uploadIcon: "hidden",
                          }}
                          config={{
                            appendOnPaste: true,
                            mode: "auto",
                          }}
                          onUploadBegin={() => {
                            setIsCardThumbnailUploading(true);
                          }}
                          onClientUploadComplete={(url) => {
                            setCardThumbnailUrl(url[0].url);
                            form.setValue("card_thumbnail", url[0].url);
                            setIsCardThumbnailUploading(false);
                          }}
                        />
                      )}
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full bg-blue-100">
              Submit
            </Button>
          </form>
        </Form>
      </ScrollArea>
    </Modal>
  );
};

export default UpdateVideoModal;
