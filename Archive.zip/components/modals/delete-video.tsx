import { Button } from "@/components/ui/button";
import { deleteVideo } from "@/lib/mutations/videos/video";
import { ApiResponse, VideoWithRelations } from "@/lib/types";
import { useAuthModal } from "@/store/modal";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import React, { useEffect } from "react";
import { toast } from "sonner";
import { Modal } from "../ui/modal";

interface Props {
  videoToDelete: VideoWithRelations;
  setVideoToDelete: React.Dispatch<
    React.SetStateAction<VideoWithRelations | undefined | null>
  >;
}

const DeleteVideoModal = ({ videoToDelete, setVideoToDelete }: Props) => {
  const { isOpen, onClose, onOpen } = useAuthModal();

  const queryClient = useQueryClient();

  const { mutate: handleDeleteVideo } = useMutation<
    ApiResponse<VideoWithRelations>,
    string,
    {
      slug: string;
    }
  >({
    mutationFn: ({ slug }) => deleteVideo({ slug: slug }),
    mutationKey: ["delete-video"],
    onSuccess: ({ message }) => {
      toast.success(message);
      queryClient.invalidateQueries({
        queryKey: ["videos"],
      });
      setVideoToDelete(null);
    },
  });

  function handleClose() {
    setVideoToDelete(null);
    onClose();
  }

  function handleDelete() {
    handleDeleteVideo({ slug: videoToDelete.slug });
  }

  useEffect(() => {
    if (videoToDelete) {
      onOpen();
    }
  }, [videoToDelete, onOpen]);

  return (
    <Modal
      title={`Delete ${videoToDelete.title}?`}
      description="Confirm that you want to delete this video."
      isOpen={isOpen}
      onClose={handleClose}
    >
      <div className="flex justify-center gap-4 items-center">
        <Button onClick={handleClose}>Cancel</Button>
        <Button variant={"destructive"} onClick={handleDelete}>
          Confirm
        </Button>
      </div>
    </Modal>
  );
};

export default DeleteVideoModal;
