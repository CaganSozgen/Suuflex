"use client";

import React, { useEffect } from "react";
import { Modal } from "../ui/modal";
import { useAuthModal } from "@/store/modal";
import { useWallet } from "@suiet/wallet-kit";
import { useAuthStore } from "@/store/authStore";
import { useMutation, useQuery } from "@tanstack/react-query";
import { signIn } from "@/lib/mutations/auth/sign-in";
import { verifyAccount } from "@/lib/queries/auth/verify-account";
import { Button } from "../ui/button";
import Link from "next/link";
import { usePathname } from "next/navigation";

const VerifyAccountModal = () => {
  const { isOpen, onClose, onOpen } = useAuthModal();
  const { address, connected, disconnect } = useWallet();
  const { status, logout, setUser, setStatus } = useAuthStore();
  const pathname = usePathname();


  const { mutate,isPending } = useMutation({
    mutationFn: () => signIn(address ?? ""),
    onSuccess: ({ data }) => {
      setUser({
        ...data,
      });
      onClose();
      setStatus("authenticated");
    },
  });

  const { data: isExisting } = useQuery({
    queryKey: ["isExisting", address],
    queryFn: () => verifyAccount(address ?? ""),
    enabled: !!address && status === "unauthenticated",
  });

  useEffect(() => {
    if (status === "unauthenticated") {
      onOpen();
    }

    if (pathname === "/dashboard/complete-details") {
      onClose();
    }
  }, [status, onOpen, onClose, pathname]);

  const handleLogout = () => {
    return Promise.all([disconnect(), logout()]);
  };

  if (!connected) return null;

  return (
    <Modal
      title="Account"
      description="Login or create an account to continue."
      isOpen={isOpen}
      onClose={onClose}
    >
      {isExisting ? (
        <div className="flex items-center gap-2">
          <Button
            disabled={isPending}
            className="bg-blue-800 hover:bg-blue-950 text-white"
            onClick={() => {
              mutate();
            }}
          >
            Log in
          </Button>
          <Button
            disabled={isPending}
            className="bg-blue-800 hover:bg-blue-950 text-white"
            onClick={() => {
              handleLogout();
            }}
          >
            Log out
          </Button>
        </div>
      ) : (
        <Button asChild onClick={() => onClose()}>
          <Link href={"/dashboard/complete-details"}>Create account</Link>
        </Button>
      )}
    </Modal>
  );
};

export default VerifyAccountModal;
