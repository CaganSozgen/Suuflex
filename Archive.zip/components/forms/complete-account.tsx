"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { signUp } from "@/lib/mutations/auth/sign-up";
import { ApiResponse } from "@/lib/types";
import { UploadDropzone } from "@/lib/uploadthing";
import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";
import { completeProfileSchema } from "@/schema/complete-profile";
import { useAuthStore } from "@/store/authStore";
import { zodResolver } from "@hookform/resolvers/zod";
import { Creator, Prisma } from "@prisma/client";
import { useWallet } from "@suiet/wallet-kit";
import { useMutation } from "@tanstack/react-query";
import { Loader } from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "../ui/button";

export function CompleteCreatorProfileForm() {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const router = useRouter();

  const { address, connected } = useWallet();
  const {user, setUser, setStatus } = useAuthStore();

  const { mutate: callSignUp } = useMutation<
    ApiResponse<Creator>,
    string,
    Prisma.CreatorCreateInput
  >({
    mutationFn: ({
      name,
      profileImage,
      walletAddress,
    }: Prisma.CreatorCreateInput) =>
      signUp({
        name,
        profileImage,
        walletAddress,
      }),
    onSuccess: ({ data, message }) => {
      toast.success(message);
      form.reset();
      setImageUrl(null);
      setUser({
        ...data,
      });
      setStatus("authenticated");

      // Redirect
      router.push("/dashboard");
    },
    onError: (error) => {
      toast.error(error);
      
    },
  });
  const form = useForm<z.infer<typeof completeProfileSchema>>({
    resolver: zodResolver(completeProfileSchema),
    defaultValues: {
      walletAddress: "",
      name: "",
      profileImage: "",
    },
  });

  

  function onSubmit(values: z.infer<typeof completeProfileSchema>) {
    callSignUp(values);
  }

  useEffect(() => {
    if (connected && address) {
      form.setValue("walletAddress", address);
    }

    if(user) {
      if(user.name && user.profileImage) {
        router.push("/dashboard");
    }
  }
  }, [connected, address, form,user ,router]);

  return (
    <Card
      className={cn(
        shantell.className,
        "mx-auto max-w-md bg-black/90 border border-white/50"
      )}
    >
      <CardHeader>
        <CardTitle className="text-2xl">Complete Profile</CardTitle>
        <CardDescription>
          Fill in the required fields to complete your profile.
        </CardDescription>
      </CardHeader>
      <CardContent className="">
        <div className="w-full">
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="w-full space-y-4"
            >
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="shadcn" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="profileImage"
                render={() => (
                  <FormItem>
                    <FormLabel>Profile Image</FormLabel>
                    <FormControl className="h-full p-2 border border-dashed rounded border-white/50">
                      {imageUrl ? (
                        <div className="relative w-full h-full">
                          <Image
                            src={imageUrl}
                            width={400}
                            height={350}
                            alt="profile image"
                            className="object-cover w-full h-full overflow-hidden rounded"
                          />
                        </div>
                      ) : isUploading ? (
                        <div className="w-full h-[250px] grid place-content-center">
                          <Loader
                            className="w-6 h-6 animate-spin"
                            stroke="white"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </div>
                      ) : (
                        <UploadDropzone
                          endpoint="imageUploader"
                          appearance={{
                            button: "hidden",
                            uploadIcon: "hidden",
                          }}
                          config={{
                            appendOnPaste: true,
                            mode: "auto",
                          }}
                          onUploadBegin={() => {
                            setIsUploading(true);
                          }}
                          onClientUploadComplete={(url) => {
                            setImageUrl(url[0].url);
                            form.setValue("profileImage", url[0].url);
                            setIsUploading(false);
                          }}
                        />
                      )}
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                type="submit"
                onClick={form.handleSubmit(onSubmit)}
                className="w-full mt-4 bg-blue-100"
              >
                {/* {isPendingCallSignUp ? (
                  <Loader
                    className="w-6 h-6 animate-spin"
                    stroke="white"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                ) : (
                  "Complete Profile"
                )} */}
                Complete Profile
              </Button>
            </form>
          </Form>
        </div>
      </CardContent>
    </Card>
  );
}
