"use client";

import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import React from "react";
import { usePathname } from "next/navigation";
import SuuflexFooter from "@/icon/suuflex-footer";
import { socials } from "@/lib/constant";
import Link from "next/link";

const Footer = () => {
  const pathname = usePathname();

  if (pathname === "/") return null;

  return (
    <footer className="flex p-16 justify-center items-center self-stretch">
      <div className="flex flex-col lg:flex-row gap-16 items-center container justify-between lg:items-start flex-1">
        <div className="flex flex-col items-center lg:items-start gap-4 max-w-[316px]">
          <SuuflexFooter />
          <p
            className={cn(
              alexandria.className,
              "ty-descriptions text-white/50"
            )}
          >
            One and only video streaming platform made on top of Sui Network.
          </p>
          <p className={cn(alexandria.className, "ty-subtext text-white/50")}>
            &copy;2024 | All rights reserved.
          </p>
        </div>
        <div className="flex flex-col items-start gap-2">
          {socials.map((social, index) => (
            <Link
              href={social.href}
              target={social.isExternal ? "_blank" : "_self"}
              rel="noopener noreferrer"
              key={index}
              className="p-2 flex items-center gap-2 self-stretch"
            >
              {social.icon}{" "}
              <span className={cn(shantell.className, "text-white")}>
                {social.name}
              </span>
            </Link>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
