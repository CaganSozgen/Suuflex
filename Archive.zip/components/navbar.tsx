"use client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useScrollPosition } from "@/hooks/useScrollPosition";
import SuuflexIcon from "@/icon/suuflex";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import { useAuthStore } from "@/store/authStore";
import { addressEllipsis, useWallet } from "@suiet/wallet-kit";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Connectwallet } from "./connect-wallet";
import { useEditProfileModal } from "@/store/editProfile";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { MenuIcon } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";

const Navbar = () => {
  const pathname = usePathname();
  const { scrollPosition } = useScrollPosition();
  const { status, address, disconnect } = useWallet();

  const [mobileDropDownOpen, setMobileDropDownOpen] = useState(false);
  const { logout } = useAuthStore();
  const router = useRouter();
  const { isOpen, onClose, onOpen } = useEditProfileModal();

  const handleLogout = () => {
    localStorage.removeItem("user");
    return Promise.all([disconnect(), logout()]);
  };

  const navigation = [
    {
      name: "SuuEpisodes",
      link: "/dashboard/#SuuEpisodes",
    },
    {
      name: "SuuNews",
      link: `/dashboard/#SuuNews`,
    },
    {
      name: "SuuEducation",
      link: "/dashboard/#SuuEducation",
    },
    {
      name: "Aboutsuuu",
      link: "/dashboard/aboutsuuu",
    },
  ];

  if (pathname === "/") return null;

  return (
    <div
      className={cn(
        "flex justify-center items-center fixed top-0 left-0 px-4 lg:px-8 w-full z-50 ease-out duration-300",
        `${scrollPosition > 50 ? "bg-black" : ""}`
      )}
    >
      <div className="flex flex-row items-center justify-between max-w-[1440px] grow">
        <div className="flex items-center gap-8">
          <Link aria-label="SuuFlex Home" href="/dashboard">
            <SuuflexIcon className="max-w-[137.353px]" />
          </Link>
          <div className="flex-wrap items-center hidden gap-4 lg:flex">
            {navigation.map((data, index) => {
              return (
                <Link
                  key={index}
                  href={data.link}
                  className={cn(
                    "p-4  text-base font-semibold",
                    shantell.className
                  )}
                >
                  {data.name}
                </Link>
              );
            })}
          </div>
        </div>{" "}
        <div className="hidden lg:flex items-center gap-4">
          <Link href={"/donators"} className="flex items-center gap-2 p-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
            >
              <path
                d="M4 11V15C4 18.2998 4 19.9497 5.02513 20.9749C6.05025 22 7.70017 22 11 22H13C16.2998 22 17.9497 22 18.9749 20.9749C20 19.9497 20 18.2998 20 15V11"
                stroke="#EBF4FF"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M3 9C3 8.25231 3 7.87846 3.20096 7.6C3.33261 7.41758 3.52197 7.26609 3.75 7.16077C4.09808 7 4.56538 7 5.5 7H18.5C19.4346 7 19.9019 7 20.25 7.16077C20.478 7.26609 20.6674 7.41758 20.799 7.6C21 7.87846 21 8.25231 21 9C21 9.74769 21 10.1215 20.799 10.4C20.6674 10.5824 20.478 10.7339 20.25 10.8392C19.9019 11 19.4346 11 18.5 11H5.5C4.56538 11 4.09808 11 3.75 10.8392C3.52197 10.7339 3.33261 10.5824 3.20096 10.4C3 10.1215 3 9.74769 3 9Z"
                stroke="#EBF4FF"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              <path
                d="M6 3.78571C6 2.79949 6.79949 2 7.78571 2H8.14286C10.2731 2 12 3.7269 12 5.85714V7H9.21429C7.43908 7 6 5.56091 6 3.78571Z"
                stroke="#EBF4FF"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              <path
                d="M18 3.78571C18 2.79949 17.2005 2 16.2143 2H15.8571C13.7269 2 12 3.7269 12 5.85714V7H14.7857C16.5609 7 18 5.56091 18 3.78571Z"
                stroke="#EBF4FF"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              <path
                d="M12 11V22"
                stroke="#EBF4FF"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>

            <p className={cn(shantell.className,'font-semibold whitespace-nowrap')}>Top Donators</p>
          </Link>
          {status === "connected" && address ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className={cn(
                    shantell.className,
                    "p-4  bg-blue-100 text-base font-semibold text-black flex items-center gap-2"
                  )}
                >
                  {addressEllipsis(address)}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M18 9.00005C18 9.00005 13.5811 15 12 15C10.4188 15 6 9 6 9"
                      stroke="#141B34"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="flex flex-col items-center justify-center w-56 gap-2 p-2 bg-white rounded-lg">
                <DropdownMenuItem
                  className={cn(
                    shantell.className,
                    "text-base font-semibold py-3 px-4 text-black cursor-pointer w-full text-center justify-center rounded"
                  )}
                >
                  Submit your own vid
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => {
                    onOpen();
                  }}
                  className={cn(
                    shantell.className,
                    "text-base font-semibold py-3 px-4 text-black cursor-pointer w-full text-center justify-center rounded"
                  )}
                >
                  Profile
                </DropdownMenuItem>

                <DropdownMenuItem
                  onClick={() => {
                    handleLogout();
                  }}
                  className={cn(
                    shantell.className,
                    "text-base font-semibold py-3 px-4 text-[#FF0000] cursor-pointer w-full text-center justify-center rounded"
                  )}
                >
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
              <Connectwallet />
          )}
        </div>
        <Sheet open={mobileDropDownOpen} onOpenChange={setMobileDropDownOpen}>
          <SheetTrigger className="lg:hidden">
            <MenuIcon size={16} />
            <p className="sr-only">Mobile Menu Bar</p>
          </SheetTrigger>
          <SheetContent className="z-[999]">
            <SheetHeader>
              <SheetTitle>
                <p className={cn(shantell.className, "ty-h5")}>SuuFlex</p>
              </SheetTitle>
            </SheetHeader>

            <div className="flex flex-col gap-2 my-8">
              {navigation.map((data, index) => {
                return (
                  <Link
                    key={index}
                    href={data.link}
                    className={cn(
                      shantell.className,
                      "p-4 text-base font-semibold hover:bg-blue-100 rounded-lg"
                    )}
                  >
                    {data.name}
                  </Link>
                );
              })}
            </div>

            <div className="">
              {status === "connected" && address ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      className={cn(
                        shantell.className,
                        "p-4 w-full bg-blue-100 text-base font-semibold text-black flex justify-between items-center gap-2"
                      )}
                    >
                      {addressEllipsis(address)}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <path
                          d="M18 9.00005C18 9.00005 13.5811 15 12 15C10.4188 15 6 9 6 9"
                          stroke="#141B34"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="z-[999] flex flex-col items-center justify-center w-full gap-2 p-2 bg-white rounded-lg">
                    <DropdownMenuItem
                      className={cn(
                        shantell.className,
                        "text-base font-semibold py-3 px-4 text-black cursor-pointer w-full text-center justify-center rounded"
                      )}
                    >
                      Submit your own vid
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => {
                        setMobileDropDownOpen(false);
                        onOpen();
                      }}
                      className={cn(
                        shantell.className,
                        "text-base font-semibold py-3 px-4 text-black cursor-pointer w-full text-center justify-center rounded"
                      )}
                    >
                      Profile
                    </DropdownMenuItem>

                    <DropdownMenuItem
                      onClick={() => {
                        handleLogout();
                      }}
                      className={cn(
                        shantell.className,
                        "text-base font-semibold py-3 px-4 text-[#FF0000] cursor-pointer w-full text-center justify-center rounded"
                      )}
                    >
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Connectwallet />
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  );
};

export default Navbar;
