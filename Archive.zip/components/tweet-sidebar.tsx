"use client";

import { fetchTweets } from "@/lib/queries/tweets";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import { useQuery } from "@tanstack/react-query";
import React from "react";
import { Tweet } from "react-tweet";
import { Button } from "./ui/button";
import LT from "@/icon/lt";
import GT from "@/icon/gt";

type SelectedHashTag = "SuuNews" | "SuuEducation" | "WeirdflexbutOK";

const hashTags: SelectedHashTag[] = [
  "SuuNews",
  "SuuEducation",
  "WeirdflexbutOK",
];

const TweetSidebar = () => {
  const [selectedHashTag, setSelectedHashTag] =
    React.useState<SelectedHashTag>("SuuNews");

  const { data: tweets } = useQuery({
    queryKey: ["tweets", selectedHashTag],
    queryFn: () => fetchTweets({ query: selectedHashTag }),
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });

  const handleNextHashTag = () => {
    const currentIndex = hashTags.indexOf(selectedHashTag);
    const nextIndex = (currentIndex + 1) % hashTags.length;
    setSelectedHashTag(hashTags[nextIndex]);
  };

  const handlePreviousHashTag = () => {
    const currentIndex = hashTags.indexOf(selectedHashTag);
    const prevIndex = (currentIndex - 1 + hashTags.length) % hashTags.length;
    setSelectedHashTag(hashTags[prevIndex]);
  };

  return (
    <div className="flex flex-col items-start gap-6">
      <div className="flex flex-col items-start self-stretch gap-4">
        <div className="flex items-center justify-between w-full">
          <p className={cn(shantell.className, "text-white ty-h6 text-[20px]")}>
            #{selectedHashTag} on X
          </p>

          <div className="flex items-center justify-end gap-2">
            <Button
              variant={"outline"}
              className="rounded-lg flex p-2 items-center bordere border-white/[.08]"
              onClick={handlePreviousHashTag}
              aria-label="Previous Hashtag"
            >
              <LT />
            </Button>
            <Button
              variant={"outline"}
              className="rounded-lg flex p-2 items-center bordere border-white/[.08]"
              onClick={handleNextHashTag}
              aria-label="Next Hashtag"
            >
              <GT />
            </Button>
          </div>
        </div>
        <p className={cn(alexandria.className, "text-white/50")}>
          Be updated with {selectedHashTag} posted on X
        </p>
      </div>

      <div className="flex flex-col items-start justify-center w-full gap-4">
        <div className="w-full">
          {tweets && tweets.data.meta.result_count === 0 ? (
            <div className="flex justify-center w-full flex1">
              <p className={cn(shantell.className, "text-center ty-h6")}>
                Start posting your thoughts on X with the hashtag {selectedHashTag}
              </p>
            </div>
          ) : (
            <div className="w-full">
              {tweets && tweets.data.tweets.map((tweet) => (
                <Tweet id={tweet.id} key={tweet.id} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TweetSidebar;
