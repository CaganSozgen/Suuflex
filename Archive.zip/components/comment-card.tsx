"use client";

import Dislike from "@/icon/dislike";
import Like from "@/icon/like";
import { vote } from "@/lib/mutations/comments/vote/vote";
import { CommentWithRelations, VideoWithRelations } from "@/lib/types";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import { useAuthStore } from "@/store/authStore";
import { VoteEnum } from "@prisma/client";
import { addressEllipsis, useWallet } from "@suiet/wallet-kit";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import Image from "next/image";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { useState } from "react";
import { Loader } from "lucide-react";
interface Props {
  video: VideoWithRelations;
  comment: CommentWithRelations;
}
const CommentCard = ({ comment, video }: Props) => {
  const { address } = useWallet();
  const { user } = useAuthStore();
  const [voteType, setVoteType] = useState<VoteEnum | null>(null);

  const userVote = comment.votes.find((vote) => vote.voterId === user?.id);

  const queryClient = useQueryClient();

  const { mutate, isPending: isVoting } = useMutation({
    mutationFn: (likeOrDislike: VoteEnum) =>
      vote({
        commentId: comment.id,
        videoId: video.id,
        voterId: user?.id ?? "",
        vote: likeOrDislike,
      }),
    mutationKey: ["vote", comment.id, video.id, user?.id],
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey :['video',video.slug]
      });
    }
  });

  return (
    <div className="flex flex-row gap-3 items-start rounded-2xl border border-white/[.08] p-4 w-full">
      <Image
        src={comment.creator?.profileImage || ""}
        alt={"logo"}
        height={14}
        width={14}
        className="rounded-full"
      />
      <div className="flex flex-col items-start w-full gap-4">
        <h1
          className={cn(
            alexandria.className,
            "text-white/[.72] ty-descriptions"
          )}
        >
          {comment.creatorId === address ? (
            <span>@{addressEllipsis(address)} (you)</span>
          ) : (
            addressEllipsis(comment.creator?.walletAddress ?? "")
          )}
        </h1>
        <Textarea
          value={comment.text}
          disabled
          className="disabled:cursor-auto"
        />

        <div className="flex items-start gap-2">
          <Button
            onClick={() => {
              setVoteType(VoteEnum.LIKE);
              mutate(VoteEnum.LIKE);
            }}
            disabled={userVote?.likeOrDislike === VoteEnum.LIKE} // Disable if already liked
            className="hover:bg-black bg-white/[.08] flex items-center justify-center px-2 py-[6px] gap-2"
          >
            {voteType === VoteEnum.LIKE && isVoting ? (
              <>
                <Loader
                  className="w-4 h-4 animate-spin"
                  stroke="white"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </>
            ) : (
              <>
                <Like className="size-2" />
                <span className={cn(shantell.className, "text-white/50")}>
                  {comment.likes}
                </span>
              </>
            )}
          </Button>
          <Button
            onClick={() => {
              setVoteType(VoteEnum.DISLIKE);
              mutate(VoteEnum.DISLIKE);
            }}
            disabled={userVote?.likeOrDislike === VoteEnum.DISLIKE} // Disable if already disliked
            className="hover:bg-black bg-white/[.08] flex items-center justify-center px-2 py-[6px] gap-2"
          >
            {voteType === VoteEnum.DISLIKE && isVoting ? (
              <>
                <Loader
                  className="w-4 h-4 animate-spin"
                  stroke="white"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </>
            ) : (
              <>
                <Dislike className="size-2" />
                <span className={cn(shantell.className, "text-white/50")}>
                  {comment.dislikes}
                </span>
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CommentCard;
