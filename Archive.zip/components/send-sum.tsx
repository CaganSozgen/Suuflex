import { Input } from "@/components/ui/input";
import { useTokenBalance } from "@/hooks/useTokenBalance";
import { ADMIN_WALLET, SUU_ADDRESS } from "@/lib/constant";
import { addTip } from "@/lib/mutations/tips/tips";
import { VideoWithRelations } from "@/lib/types";
import { cn } from "@/lib/utils";
import { alexandria, shantell } from "@/public/fonts";
import { getFullnodeUrl, SuiClient } from "@mysten/sui/client";
import { Transaction } from "@mysten/sui/transactions";
import { MIST_PER_SUI } from "@mysten/sui/utils";
import { useWallet } from "@suiet/wallet-kit";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "./ui/button";
import numeral from "numeral";
import { Loader } from "lucide-react";
import { NumericFormat } from "react-number-format";

interface ISendSum {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  video: VideoWithRelations;
}
const rpcUrl = getFullnodeUrl(
  process.env.NODE_ENV === "development" ? "mainnet" : "mainnet"
);
const client = new SuiClient({ url: rpcUrl });

const SendSum = ({ isOpen, setIsOpen, video }: ISendSum) => {
  const [tipAmount, setTipAmount] = useState(0);
  const { signAndExecuteTransaction, address, connected, on, status } =
    useWallet();

  const queryClient = useQueryClient();

  const { mutate: tipVideo, isPending } = useMutation({
    mutationFn: addTip,
    mutationKey: ["add-tip"],
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["video", video.slug],
      });

      setIsOpen(false);
      setTipAmount(0);
      toast.success("Video tipped successfully");
    },
    onError: (error: string) => {
      toast.error(error);
    },
  });

  const SUU_OBJECT_ID =
    "0xdaae7f7964d2ecaf7455e96f6ee5875db8631246141350409398815b781d46b6";

  const { balance: suuBalance } = useTokenBalance(SUU_ADDRESS);

  const tipSuu = async () => {
    try {
      const tx = new Transaction();

      const mistAmount = tipAmount * Number(MIST_PER_SUI);

      const obj = tx.object(SUU_OBJECT_ID);

      const [coin] = tx.splitCoins(obj, [mistAmount]);

      tx.transferObjects([coin], ADMIN_WALLET);

      const result = await signAndExecuteTransaction({
        transaction: tx,
      });

      const digest = await client.waitForTransaction({ digest: result.digest });

      if (digest && address) {
        tipVideo({
          walletAddress: address,
          tipAmount: tipAmount,
          videoId: video.id,
          ticker: "SUU",
        });
      }
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      }
    }
  };

  const supportersCount = new Set(video.tips.map((tip) => tip.tipperId)).size;


  if (!isOpen) return null;

  return (
    <div className="fixed top-0 left-0 flex justify-center items-center h-full w-full backdrop-blur-lg bg-black/50 z-[999] p-4">
      <div className="flex flex-col gap-4 items-center  w-fit rounded-2xl border border-white/[.08] bg-black/100 p-4">
        <div className="flex flex-col w-full gap-2">
          <h1 className={cn(shantell.className, " ty-h6")}>Send sum $SUU</h1>
          <h1
            className={cn(
              alexandria.className,
              "ty-descriptions text-white/50"
            )}
          >
            Spreading suuuum luv &lt;3
          </h1>
        </div>
        <div className="flex flex-col items-center justify-center p-4 sm:flex-row grow">
          <div className="flex flex-col gap-2 p-2 items-center justify-center min-w-[154.5px]">
            <h1 className={cn(shantell.className, " ty-h5")}>
              {numeral(video.total_suu_tips).format("0a")}
            </h1>

            <p
              className={cn(alexandria.className, "text-white/50 ty-subtitle")}
            >
              $SUU received
            </p>
          </div>
          <div className="flex flex-col gap-2 p-2 items-center justify-center min-w-[154.5px]">
            <h1 className={cn(shantell.className, " ty-h5")}>
              {supportersCount}
            </h1>

            <p
              className={cn(alexandria.className, "text-white/50 ty-subtitle")}
            >
              Suuuupporters
            </p>
          </div>
        </div>

        <div className="px-4 py-3 flex flex-row gap-2 items-center rounded-2xl border border-white/[.16] w-full">
          <NumericFormat
            value={tipAmount}
            defaultValue={10}
            allowLeadingZeros={false}
            thousandSeparator=","
            onValueChange={(values) => {
              setTipAmount(values.floatValue ?? 10);
            }}
            className="w-full"
          />
          <h1 className={cn(alexandria.className, "ty-title ")}>$SUU</h1>
        </div>

        <div className="flex flex-wrap items-center justify-between w-full gap-2">
          <button
            onClick={() => setIsOpen(false)}
            className={cn(
              shantell.className,
              "rounded-lg bg-white/[.08] py-3 px-4  text-base font-semibold"
            )}
          >
            Cancel :(
          </button>
          <Button
            disabled={tipAmount > suuBalance || tipAmount <= 0 || isPending}
            onClick={() => {
              tipSuu();
            }}
            className={cn(
              shantell.className,
              "rounded-lg bg-blue-100 py-3 px-4  text-base font-semibold"
            )}
          >
            {isPending ? (
              <Loader
                className="w-4 h-4 animate-spin"
                stroke="white"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            ) : (
              "Tip with $SUU"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SendSum;
