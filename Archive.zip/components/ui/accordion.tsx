"use client";

import * as React from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { cn } from "@/lib/utils";
import { alexandria } from "@/public/fonts";

const Accordion = AccordionPrimitive.Root;

const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item ref={ref} className={cn("", className)} {...props} />
));
AccordionItem.displayName = "AccordionItem";

const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Header className="flex">
    <AccordionPrimitive.Trigger
      ref={ref}
      className={cn(
        "flex flex-1 items-center justify-between py-4 relative z-[2] ty-subtitle text-white-50 rounded-2xl bg-[#1c2326] p-4 transition-all [&[data-state=open]>svg]:rotate-180",
        className
      )}
      {...props}
    >
      {children}

      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
        className="rotate-180"
      >
        <path
          d="M12.3957 10.5368C12.6921 10.3185 12.7554 9.90117 12.5371 9.60471C12.3675 9.37443 12.1979 9.15555 12.0491 8.96488C11.7521 8.58435 11.3432 8.07461 10.8989 7.56301C10.4576 7.05468 9.96819 6.52915 9.51139 6.12548C9.28372 5.92435 9.04839 5.73935 8.81892 5.60101C8.60779 5.47375 8.31766 5.33341 8.00026 5.33341C7.68286 5.33341 7.39266 5.47375 7.18152 5.60101C6.95206 5.73935 6.71679 5.92435 6.48913 6.12548C6.03227 6.52915 5.54291 7.05468 5.10155 7.56301C4.65731 8.07461 4.24843 8.58435 3.95142 8.96488C3.80264 9.15555 3.63301 9.37443 3.46341 9.6047C3.24507 9.90117 3.3084 10.3185 3.60486 10.5368C3.72403 10.6246 3.86274 10.6669 4.00021 10.6667H8.00026H12.0003C12.1377 10.6669 12.2765 10.6246 12.3957 10.5368Z"
          fill="#EBF4FF"
          fillOpacity="0.5"
        />
      </svg>
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
));
AccordionTrigger.displayName = AccordionPrimitive.Trigger.displayName;

const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Content
    ref={ref}
    className={cn(
      alexandria.className,
      "overflow-hidden ty-descriptions -mt-3 z-[1] relative bg-white-4 text-white-100 data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down rounded-b-2xl"
    )}
    {...props}
  >
    <div className={cn("pt-6 pb-4 px-4", className)}>{children}</div>
  </AccordionPrimitive.Content>
));
AccordionContent.displayName = AccordionPrimitive.Content.displayName;

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };
