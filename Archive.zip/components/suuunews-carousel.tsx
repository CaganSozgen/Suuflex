// "use client";
// import React from "react";
// import {
//   Carousel,
//   CarouselContent,
//   CarouselItem,
//   CarouselNext,
//   CarouselPrevious,
// } from "@/components/ui/carousel";
// import { cn } from "@/lib/utils";
// import { alexandria, shantell } from "@/public/fonts";
// import Image from "next/image";
// import { Video } from "@prisma/client";
// import Link from "next/link";
// import { VideoWithRelations } from "@/lib/types";

// interface Props {
//   category: string;
//   videos: VideoWithRelations[];
// }

// const CategoryCarousel = ({ category, videos }: Props) => {
//   return (
//     <div id={category} className="flex justify-center items-center pb-16">
//       <div className="flex flex-col gap-8 items-center max-w-[1440px] w-full px-4">
//         <h1 className={cn(shantell.className, "ty-h3  sm:w-full")}>
//           {category}
//         </h1>
//         <Carousel className="w-full ">
//           <CarouselContent>
//             {videos.map((video, index) => (
//               <CarouselItem
//                 key={index}
//                 className="sm:basis-1/2 md:basis-1/3 lg:basis-1/4 xl:basis-1/5 group flex items-stretch"
//               >
//                 <Link
//                   href={`/dashboard/${video.slug}`}
//                   className="flex flex-col gap-4 p-4 items-start rounded-2xl group-hover:border-blue-100 bg-transparent group-hover:bg-white/[.04] border border-transparent"
//                 >
//                   <Image
//                     src={video.thumbnail}
//                     alt={"dashboard"}
//                     height={300}
//                     width={200}
//                     className="w-full max-h-[300px] min-h-[300px] rounded-lg object-cover"
//                   />

//                   <div className="flex flex-col gap-2">
//                     <div className="flex flex-row gap-1 items-center">
//                       <Image
//                         src={video.thumbnail}
//                         alt={"logo"}
//                         height={14}
//                         width={14}
//                         className="size-[20px] aspect-square rounded-full"
//                       />
//                       <p
//                         className={cn(
//                           alexandria.className,
//                           "ty-subtitle text-white/50 line-clamp-2 text-ellipsis"
//                         )}
//                       >
//                         {video.title}
//                       </p>
//                     </div>
//                     <p
//                       className={cn(
//                         alexandria.className,
//                         "ty-subtitle  min-h-[48px] line-clamp-3 text-ellipsis"
//                       )}
//                     >
//                       {video.description}
//                     </p>
//                   </div>
//                 </Link>
//               </CarouselItem>
//             ))}
//           </CarouselContent>
//           <CarouselPrevious />
//           <CarouselNext />
//         </Carousel>
//       </div>
//     </div>
//   );
// };

// export default CategoryCarousel;
