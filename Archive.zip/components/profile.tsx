import { updateCreator } from "@/lib/mutations/creators/creator";
import { UploadDropzone } from "@/lib/uploadthing";
import { cn } from "@/lib/utils";
import { shantell } from "@/public/fonts";
import { editProfileSchema } from "@/schema/edit-profile";
import { useAuthStore } from "@/store/authStore";
import { useEditProfileModal } from "@/store/editProfile";
import { zodResolver } from "@hookform/resolvers/zod";
import { useWallet } from "@suiet/wallet-kit";
import { useMutation } from "@tanstack/react-query";
import { Edit, Loader, Pencil, X } from "lucide-react";
import Image from "next/image";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "./ui/form";
import { Input } from "./ui/input";
import { Modal } from "./ui/modal";
/* 
const Profile = () => {
  const { user } = useAuthStore();

  if (!user) return null;

  return (
    <div className="flex items-center gap-2 text-center">
      <Avatar
        onClick={onOpen}
        className="relative w-16 h-16 transition duration-200 group"
      >
        <AvatarImage src={user.profileImage} alt="Profile picture" />
        <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>

        <div className="absolute inset-0 hidden duration-200 cursor-pointer group-hover:grid place-content-center bg-black/50">
        <Pencil size={14}/>
        </div>
      </Avatar>
      <h2 className={cn(shantell.className, "ty-descriptions text-[20px]")}>
        @{user.name}
      </h2>

      <ProfileEdit />
    </div>
  );
};

export default Profile;
 */
const ProfileEditModal = () => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const { address, connected } = useWallet();

  const { isOpen, onClose, onOpen } = useEditProfileModal();
  const { user, setUser } = useAuthStore();

  const { mutate, isPending } = useMutation({
    mutationFn: updateCreator,
    mutationKey: ["update-creator"],
    onSuccess: ({ data }) => {
      setUser(data);
      toast.success("Profile updated successfully.");
      onClose();
    },
  });

  const form = useForm<z.infer<typeof editProfileSchema>>({
    resolver: zodResolver(editProfileSchema),
    defaultValues: {
      name: user?.name,
      profileImage: user?.profileImage,
    },
  });

  const onSubmit = (values: z.infer<typeof editProfileSchema>) => {
    if (user && connected && address) {
      mutate({
        id: user.id,
        body: {
          ...values,
        },
        walletAddress: address,
      });
    }
  };

  if(!user) {
    return null;
  }

  return (
    <Modal
      title="Edit Profile"
      description="Fill in the required fields to edit your profile."
      isOpen={isOpen}
      onClose={onClose}
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Name</FormLabel>
                <FormControl>
                  <Input placeholder={user?.name} {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="profileImage"
            render={() => (
              <FormItem className="space-y-4">
                <FormLabel>Profile Image</FormLabel>
                <Image
                  src={user.profileImage}
                  width={80}
                  height={80}
                  alt="profile image"
                  className="rounded-full max-w-[80px] w-full h-[80px] object-cover"
                />
                <FormControl className="relative h-full p-2 border border-dashed rounded border-white/50">
                  <div className="relative">
                    {imageUrl && (
                      <X
                        onClick={() => setImageUrl(null)}
                        className="absolute top-0 right-0 z-10 w-4 h-4 -m-2 bg-red-300 rounded-full cursor-pointer"
                      />
                    )}
                    {imageUrl ? (
                      <div className="relative w-full h-full">
                        <Image
                          src={imageUrl}
                          width={400}
                          height={350}
                          alt="profile image"
                          className="object-cover w-full h-full overflow-hidden rounded max-h-[200px]"
                        />
                      </div>
                    ) : isUploading ? (
                      <div className="w-full h-[250px] grid place-content-center">
                        <Loader
                          className="w-6 h-6 animate-spin"
                          stroke="white"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </div>
                    ) : (
                      <UploadDropzone
                        endpoint="imageUploader"
                        appearance={{
                          button: "hidden",
                          uploadIcon: "hidden",
                        }}
                        config={{
                          appendOnPaste: true,
                          mode: "auto",
                        }}
                        onUploadBegin={() => {
                          setIsUploading(true);
                        }}
                        onClientUploadComplete={(url) => {
                          setImageUrl(url[0].url);
                          form.setValue("profileImage", url[0].url);
                          setIsUploading(false);
                        }}
                      />
                    )}
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex items-center justify-center gap-4">
            <Button
              type="button"
              className="flex-1 text-black"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button
              disabled={isPending}
              type="submit"
              className="flex-1 text-black bg-blue-100"
            >
              Save Changes
            </Button>
          </div>
        </form>
      </Form>
    </Modal>
  );
};

export default ProfileEditModal;